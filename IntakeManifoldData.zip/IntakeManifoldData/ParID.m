function parOpt = ParID(par0, opt)
% par0 = [Vm0, lambda_lw0]

opts = optimset('Display','iter','MaxIter',60,'TolX',1e-4,'TolFun',1e-4);
cost = @(p) Modelerror(p, opt);

parOpt = fminsearch(cost, par0, opts);
end