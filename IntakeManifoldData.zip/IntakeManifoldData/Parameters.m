% Parameters.m  -- known constants, ICs, sim options, initial guesses

% constants
R = 287;    % J/kgK
Cv = 718;   % J/kgK
Cp = 1005;  % J/kgK
kappa = Cp/Cv;

Vd = 2.5e-3;     % m^3  (engine displacement)
epsilon = 10;    % compression ratio-ish modeling constant
pe = 1e5;        % exhaust/back pressure [Pa]
omega_e = 125;   % rad/s (example)

% initial conditions
p0 = 1e5;    % Pa
theta0 = 295; % K

% tunables (initial guess)
Vm        = 3 * 2.5e-3;  % m^3 (e.g. 3x displacement volume)
lambda_lw = 1.0;

% simulation options
Ts    = 0.01;
t_end = 60;