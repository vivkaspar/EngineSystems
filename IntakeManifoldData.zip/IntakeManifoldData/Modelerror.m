function J = Modelerror(p, opt)
% p = [Vm, lambda_lw]
Vm        = p(1);
lambda_lw = p(2);

% Make sure only Output logging produces 'yout'
set_param(opt.model, ...
    'SaveOutput','on', 'OutputSaveName','yout', 'SaveFormat','Dataset', ...
    'SignalLogging','off');

% Build SimulationInput
in = Simulink.SimulationInput(opt.model);
in = in.setExternalInput(opt.ds);
in = in.setModelParameter('StopTime', num2str(opt.t(end)), ...
                          'SolverType','Fixed-step', 'FixedStep', num2str(opt.Ts));

% Push constants (from base, since Parameters.m is a script)
constNames = {'R','Cv','Cp','kappa','Vd','epsilon','pe','omega_e','p0','theta0'};
for k = 1:numel(constNames)
    if evalin('base', sprintf('exist(''%s'',''var'')', constNames{k}))
        in = in.setVariable(constNames{k}, evalin('base', constNames{k}));
    end
end

% Push tunables
in = in.setVariable('Vm',        Vm);
in = in.setVariable('lambda_lw', lambda_lw);

% Simulate
out = sim(in);

% Extract 'pressure' from yout
yout = out.get('yout');                              % Dataset
idx  = find(strcmpi({yout.Name}, opt.yName), 1);
if isempty(idx), idx = 1; end
ts = yout{idx}.Values;

% Resample to measurement times
sim_p = interp1(ts.Time, ts.Data, opt.t, 'linear','extrap');

% Least-squares cost
e = sim_p - opt.y_meas;
J = (e.'*e) / numel(e);

% Optional live plotting (toggle with opt.showFit)
if isfield(opt,'showFit') && opt.showFit
    persistent hfig
    if isempty(hfig) || ~isvalid(hfig), hfig = figure('Name','Live fit'); end
    figure(hfig); clf
    plot(opt.t, opt.y_meas, 'k', 'DisplayName','Measured p'); hold on
    plot(opt.t, sim_p, 'r--', 'DisplayName','Simulated p');
    xlabel('Time [s]'); ylabel('Pa'); grid on; legend('Location','best')
    title(sprintf('Vm = %.4g m^3, \\lambda_{lw} = %.3g, J = %.3g', Vm, lambda_lw, J));
    drawnow;
end
end