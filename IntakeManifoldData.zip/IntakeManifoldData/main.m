%% MAIN — run, identify Vm & lambda_lw, validate
clear; clc; close all;

% 1) Parameters & data
run Parameters.m;                        % puts constants, ICs, Ts, Vm, lambda_lw in base
load('DataIdentification.mat');          % IdData.mdot_in, IdData.p

t      = IdData.mdot_in.time(:);
u_mdot = IdData.mdot_in.signals.values(:);
y_meas = IdData.p.signals.values(:);

% 2) External inputs (Dataset for root Inports)
mdot_in_ts  = timeseries(u_mdot, t);
theta_in_ts = timeseries(295*ones(size(t)), t);

ds = Simulink.SimulationData.Dataset;
ds = ds.addElement(mdot_in_ts , 'm_dot_in');
ds = ds.addElement(theta_in_ts, 'theta_in');

% 3) Pack options for cost
opt.model  = 'IntakeManifold_Model';
opt.ds     = ds;
opt.t      = t;
opt.Ts     = Ts;
opt.y_meas = y_meas;
opt.yName  = 'pressure';
opt.showFit = false;   % set true to see live plot during optimization

% 4) Initial guess and identify
par0   = [Vm, lambda_lw];
parOpt = ParID(par0, opt);

Vm_opt        = parOpt(1);
lambda_lw_opt = parOpt(2);
fprintf('\nOptimized parameters:\n  Vm = %.6g m^3\n  lambda_lw = %.6g\n', Vm_opt, lambda_lw_opt);

% 5) Final simulation with optimal parameters (one more call to Modelerror to get the fit)
opt.showFit = false;
Jfinal = Modelerror([Vm_opt, lambda_lw_opt], opt); %#ok<NASGU> (runs and can plot if showFit=true)

% If you want the final overlay figure explicitly:
set_param(opt.model, 'SaveOutput','on','OutputSaveName','yout','SaveFormat','Dataset','SignalLogging','off');
in = Simulink.SimulationInput(opt.model);
in = in.setExternalInput(opt.ds);
in = in.setModelParameter('StopTime', num2str(t(end)), ...
                          'SolverType','Fixed-step','FixedStep', num2str(opt.Ts));

% constants again (from base)
constNames = {'R','Cv','Cp','kappa','Vd','epsilon','pe','omega_e','p0','theta0'};
for k = 1:numel(constNames)
    if evalin('base', sprintf('exist(''%s'',''var'')', constNames{k}))
        in = in.setVariable(constNames{k}, evalin('base', constNames{k}));
    end
end

% optimal tunables
in = in.setVariable('Vm',        Vm_opt);
in = in.setVariable('lambda_lw', lambda_lw_opt);

out = sim(in);
yout = out.get('yout');
idx  = find(strcmpi({yout.Name}, opt.yName),1); if isempty(idx), idx=1; end
ts   = yout{idx}.Values;
sim_p = interp1(ts.Time, ts.Data, t, 'linear','extrap');

figure('Name','Final fit');
plot(t, y_meas,'k','DisplayName','Measured p'); hold on
plot(t, sim_p,'r--','DisplayName','Simulated p');
xlabel('Time [s]'); ylabel('Pa'); legend('Location','best'); grid on
title(sprintf('Final fit: V_m = %.4g m^3, \\lambda_{lw} = %.3g', Vm_opt, lambda_lw_opt));