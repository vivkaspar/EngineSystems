% Load the parameters
run Parameters; 

% Here we use the same data and parameter files as in the file for the
% parameter identification. This is helpful: if we change some parameters,
% we must only change it in one location.
% Calculate a "meaningful" equilibrium point around which we will linearize
% our system. Therefore, define a nominal input
u_alpha_nom  = 10; % (this is within the range of inputs of the measurement data)
alpha_0    = par.alpha_0_opt;
alpha_1    = par.alpha_1_opt;
    
% Simulate with constant input for 10 seconds (duration has to be much
% longer than the time constant of the system). The system has then reached
% steady state for sure. 
timespan = [0 10]';
Data.u_alpha.time = [0 10]';
Data.u_alpha.signals.values = u_alpha_nom * ones(size(timespan));
[t, x, y] = sim(par.ModNam, timespan, par.sim_opt);
clear timespan
    
% Plot states to make sure they have reached steady-state.
figure('Name','Steady-state');
subplot(2,1,1); grid on; box on; hold on;
    plot(t,x(:,1));
    xlabel('Time [s]');
    ylabel('Throttle Area [m^2]');
    title('State 1');

% Assign the last values of the state vector x and output vector y as the
% equilibrium values.
A_alpha_nom = y(end);

% Linearize the system using the command linmod:
linsys = linmod('manifold_NiceLayout_nom', [1 1], 1); 
% linsys = linmod('manifold_NiceLayout', x_eq, mdotin_nom); 
% Inputs are the model name, the nominal states that were reached and 
% the nominal input, with which those states can be reached

% Display the order of the states in your linear model. Sometimes it is not
% clear, which state has which state number. 
% The following code gives the name of the integrator, that simulink uses
% as the "first" state and so on
disp('SYSTEM STATES');
disp(['1st state: ', num2str(linsys.StateName{1,1}(1+max(findstr(linsys.StateName{1,1},'/')):end))]);
disp(['2nd state: ', num2str(linsys.StateName{2,1}(1+max(findstr(linsys.StateName{2,1},'/')):end))]);

% Assign the system matrices:
A = linsys.a;
B = linsys.b;
C = linsys.c;
D = linsys.d;

%% Normalizing the linear system:
% Normalization is already done using the description in the exercise 
% tutorial!
Tu  = u_alpha_nom;
Ty  = A_alpha_nom;

%% Compare the linear with the nonlinear model

% load measurement data
load DataIdentification; 
Data = IdData;
% load DataValidation.mat; Data = ValData;

% Initial conditions for the nonlinear model
% Nonlinear model
pinit           = IdData.p.signals.values(1);   % [Pa]
thetainit       = par.theta_in;                 % [K]
% Linearized/normalized model - use normalized initial conditions
pinit_lin      	= IdData.p.signals.values(1) / p_nom - 1; % [-]
thetainit_lin   = thetainit / theta_nom - 1;    % [-]

timespan        = [IdData.mdot_in.time(1) IdData.mdot_in.time(end)];
    
% Run Simulation
% Simulate the nonlinear model
[t_nonlin, x_nonlin, y_nonlin] = sim(par.ModNam, timespan, par.sim_opt);
% Simulate the linearized model. There is a new model file for the
% linearized and normalized model. We simulate each model file individually
% and compare the results in a single plot. 
[t_lin, x_lin, y_lin] = sim('manifold_linear', timespan, par.sim_opt);

% You can also put the linear and nonlinear versions into one model file,
% however the parameter identification and the normalization etc. will not
% work anymore if you work like that.

% Plot both system responses.
figure('Name','Comparison Linear and Non-linear Models');
col = lines(2);
    grid on; hold on;
    plot(t_lin([1 end]), p_nom*[1 1], 'k--')
    plot(t_nonlin, y_nonlin, 'Color', col(1,:), 'LineWidth', 2 );
    plot(t_lin, y_lin, '--', 'Color', col(2,:), 'LineWidth', 2);
    xlabel('Time [s]');
    ylabel('Intake Manifold Pressure [Pa]');
    title('Step Response');
    legend('Linearization Point', 'Nonlinear model', 'Linear model','Location','best');
    