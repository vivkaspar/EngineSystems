
%Set_opt_params
if ~exist('par','var'); par = struct(); end

% Optima nur anlegen, wenn sie noch nicht existieren
if ~isfield(par,'Vm_opt');      par.Vm_opt = 0;      end
if ~isfield(par,'alpha_0_opt'); par.alpha_0_opt = 0; end
if ~isfield(par,'alpha_1_opt'); par.alpha_1_opt = 0; end
if ~isfield(par,'gamma_0_opt'); par.gamma_0_opt = 0; end
if ~isfield(par,'gamma_1_opt'); par.gamma_1_opt = 0; end
if ~isfield(par,'eta_0_opt'); par.eta_0_opt = 0; end
if ~isfield(par,'eta_1_opt'); par.eta_1_opt = 0; end
if ~isfield(par,'beta_0_opt'); par.beta_0_opt = 0; end
if ~isfield(par,'theta_e_opt'); par.theta_e_opt = 0; end

par.alpha_0 = par.alpha_0_opt + (par.alpha_0_opt == 0) * par.alpha_0_init;
par.alpha_1 = par.alpha_1_opt + (par.alpha_1_opt == 0) * par.alpha_1_init;
par.gamma_0 = par.gamma_0_opt + (par.gamma_0_opt == 0) * par.gamma_0_init;
par.gamma_1 = par.gamma_1_opt + (par.gamma_1_opt == 0) * par.gamma_1_init;
par.Vm = par.Vm_opt + (par.Vm_opt == 0) * par.Vm_init;
par.eta_0 = par.eta_0_opt + (par.eta_0_opt == 0) * par.eta_0_init;
par.eta_1 = par.eta_1_opt + (par.eta_1_opt == 0) * par.eta_1_init;
par.beta_0 = par.beta_0_opt + (par.beta_0_opt == 0) * par.beta_0_init;
par.theta_e = par.theta_e_opt + (par.theta_e_opt == 0) * par.theta_e_init;