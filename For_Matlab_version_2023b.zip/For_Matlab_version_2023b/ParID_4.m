
%ParID_4

par0 = [par.eta_0_init, par.eta_1_init, par.beta_0_init, par.theta_e_init];

opt_options = optimset('TolFun',1e-4,'TolX',1e-4,'MaxIter',200,'MaxFunEvals',2000,'Display','iter');

Data = data_stud_1.meas;
errorfnc_fminsearch = @(par0) ModelerrorParID_4(par0, Data, par, 'Parameter Identification');
tic
optpar = fminsearch(errorfnc_fminsearch, par0, opt_options);
opt_dur = toc;

par.eta_0_opt         = optpar(1);
par.eta_1_opt         = optpar(2);
par.beta_0_opt        = optpar(3);
par.theta_e_opt       = optpar(4);


close all 

fprintf('eta_0 = %1.5f\n', par.eta_0_opt) % \n means new line, 1.5f means float variable and 5 decimals displayed
fprintf('eta_1 = %1.5f\n', par.eta_1_opt) % \n means new line, 1.5f means float variable and 5 decimals displayed
fprintf('beta_0 = %1.5f\n', par.beta_0_opt) % \n means new line, 1.5f means float variable and 5 decimals displayed
fprintf('theta_e = %1.5f\n', par.theta_e_opt) % \n means new line, 1.5f means float variable and 5 decimals displayed



% load validation data

Data = data_stud_2.meas;
% evaluate model

ModelerrorParID_4(optpar,Data,par,'Evaluation on Validation Data');
% you can simply use the plot commands which you already wrote in the 
% Modelerror file. As inputs, the identified optimal parameters are used.
