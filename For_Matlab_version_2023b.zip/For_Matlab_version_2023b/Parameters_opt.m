%Parameters_opt

clc;
clearvars;
close all;


par.alpha_0 = 0.0000012852;
par.alpha_1 = 0.0000058730;
par.gamma_0 = 0.6183933592;
par.gamma_1 = 0.0010441176;
par.Vm = 0.0076536825;
par.eta_0 = 0.4130991652;
par.eta_1 = -0.0000718339;
par.beta_0 = 19.5839293301;
par.theta_e = 0.2242802344;


par.R           = 287;
par.Vd          = 2.48e-3;
par.Vc          = 2.48e-4;
par.sigma_0     = 14.7;
par.kappa       = 1.35;
par.Hl          = 42.5e6;
par.k_zeta      = 2.3345e-4;
par.eta_gen     = 0.7;
par.lambda      = 1;


data1 = load('ISCSData/quasistatic_0001');
data2 = load('ISCSData/dynamic_0003');
data3 = load('ISCSData/dynamic_0002');
data_stud_1 = load('ISCSData/studentId_0009');
data_stud_2 = load('ISCSData/studentId_0010');

Data = data_stud_2.meas;

par.omega_e_max = max(Data.omega_e.signals.values);
par.omega_e_min = min(Data.omega_e.signals.values);


par.p_m_init     = Data.p_m.signals.values(1);
par.p_zero = Data.p_m.signals.values(1);
par.omega_zero = Data.omega_e.signals.values(1);
par.end_time = Data.omega_e.time(end);
par.du_ign_zero = Data.du_ign.signals.values(1);

disp(par.p_m_init);
disp(par.p_zero);
disp(par.omega_zero);
disp(par.end_time);
disp(par.du_ign_zero);

par.simopt = simset('Solver','ode1','FixedStep',1e-3,'SrcWorkspace','current');
par.model = 'NonlinearModel'; %choose model
[time,x,y1,y2]= sim(par.model, [Data.u_alpha.time(1), Data.u_alpha.time(end)], par.simopt);

