clc;
clearvars;
close all;
run Parameters
run ParID_1
run ParID_2
run ParID_3
run ParID_4
run set_opt_params

fprintf('alpha_0 = %1.10f\n', par.alpha_0)
fprintf('alpha_1 = %1.10f\n', par.alpha_1)
fprintf('gamma_0 = %1.10f\n', par.gamma_0)
fprintf('gamma_1 = %1.10f\n', par.gamma_1)
fprintf('Vm = %1.10f\n', par.Vm_opt)
fprintf('eta_0 = %1.10f\n', par.eta_0)
fprintf('eta_1 = %1.10f\n', par.eta_1)
fprintf('beta_0 = %1.10f\n', par.beta_0)
fprintf('theta_e = %1.10f\n', par.theta_e)



