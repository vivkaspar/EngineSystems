
%Parameters


par.R           = 287;
par.Vd          = 2.48e-3;
par.Vc          = 2.48e-4;
par.sigma_0     = 14.7;
par.kappa       = 1.35;
par.Hl          = 42.5e6;
par.k_zeta      = 2.3345e-4;
par.eta_gen     = 0.7;
par.lambda      = 1;

%par.omega_e_max = 500;
%par.omega_e_min = 20;




%Parameters to be identified
par.alpha_0_init    = 3e-6;
par.alpha_1_init    = 6e-6;
par.Vm_init         = 7e-3;
par.gamma_0_init    = 0.6;
par.gamma_1_init    = 0.002;
par.eta_0_init      = 0.3;
par.eta_1_init      = -3e-4;
par.beta_0_init     = 7;
par.theta_e_init    = 0.2;



par.alpha_0 = par.alpha_0_init;
par.alpha_1 = par.alpha_1_init;
par.gamma_0 = par.gamma_0_init;
par.gamma_1 = par.gamma_1_init;
par.Vm = par.Vm_init;
par.eta_0 =  par.eta_0_init;
par.eta_1 = par.eta_1_init;
par.beta_0 = par.beta_0_init;
par.theta_e = par.theta_e_init;




%From Workspace
data1 = load('ISCSData/quasistatic_0001');
data2 = load('ISCSData/dynamic_0003');
data3 = load('ISCSData/dynamic_0002');
data_stud_1 = load('ISCSData/studentId_0009');
data_stud_2 = load('ISCSData/studentId_0010');

Data = data_stud_1.meas; % Choose of dataset

%fieldnames(Data)  % Show Content of Data


%cont_out        = Data.cont_out;
%omega_e_deired  = Data.omega_e_desired;
%I_Gen           = Data.I_Gen;
%U_Bat           = Data.U_Bat;


% Initial value of the Integrators
%par.p_zero = Data.p_m.signals.values(1);
%par.omega_zero = Data.omega_e.signals.values(1);
%par.end_time = Data.omega_e.time(end);
%par.du_ign_zero = Data.du_ign.signals.values(1);

par.omega_e_max = max(Data.omega_e.signals.values);
par.omega_e_min = min(Data.omega_e.signals.values);

par.simopt = simset('Solver','ode1','FixedStep',1e-3,'SrcWorkspace','current');

par.model = 'NonlinearModel'; %choose model
par.enablePlot = 1;

