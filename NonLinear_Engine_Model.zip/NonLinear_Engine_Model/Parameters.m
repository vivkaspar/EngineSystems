% DEFINE INITIAL PARAMETERS FOR PARAMETER IDENTIFICATION AND LINEARIZATION

% Defining engine and environmental parameters:
par.cp          = 1003;             % [J/(kg*K)] Specific heat capacity at constant pressure.
par.cv          = 717;              % [J/(kg*K)] Specific heat capacity at constant volume.
par.kappa       = par.cp/par.cv;    % [-]        Heat capacity ratio or adiabatic index
par.epsilon     = 10;               % [-]        Compression Ratio
par.p_e         = 1e5;              % [Pa]       Pressure of the exhaust gas remaining in the cylinder.
par.R           = 287;              % [J/(kg*K)] Universal gas constant of air.
par.theta_in    = 295;              % [K]        Temperature of the air entering the intake manifold.
par.Vd          = 2.5e-3;           % [m^3]      Displacement volume of the engine
par.omega_e     = 125;              % [rad/s]    Engine speed
%PARID pars
par.alpha_0      = 3e-6;          % tbd [m^2]
par.alpha_1      = 6e-6;
par.V_m         = 7e-3;
par.gamma_0     = 0.6;
par.gamma_1     = 0.002;
par.beta0       = 7;
par.eta0        = 0.3;
par.eta1        = -3e-4;
par.Theta_e     = 0.2;
% These are the results of the parameter identification. It is used in the linearization file.
par.alpha_0_opt     = 0.000001688;
par.alpha_1_opt     = 0.000005719;
par.V_m_opt         = 0.00549;
par.gamma_0_opt     = 0.67534;
par.gamma_1_opt     = 0.00090;
par.beta0_opt       = 14.70286;
par.eta0_opt        = 0.41367;
par.eta1_opt        = -0.00022;
par.Theta_e_opt     = 0.18449;


% Model Initial conditions:
par.m_dot_alpha_init = meas.m_dot_alpha.signals.values(1);
par.p_m_init = meas.p_m.signals.values(1);
par.omega_e_init = meas.omega_e.signals.values(1);

% Define Simulation Parameters. They are set for all "sim"-commands
par.sim_opt = simset('SrcWorkspace','current','FixedStep',1e-3,'Solver','ode1'); 
% use a fixed step size, this is the same stepsize as in the measurement.
% Use current worspace option in order to let the simulation in the file
% modelerror look for parameters in its own workspace and not in the base
% matlab workspace.

%% Options

% Choose the model you want to simulate here:
par.ModNam = 'Engine_model';
% par.ModNam = 'manifold_NiceLayout';   

% Set to 1 to create a figure in the modelerror file
par.enablePlot = 1;