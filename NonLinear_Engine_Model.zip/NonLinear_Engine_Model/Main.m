clc;
clearvars;
close all;

run ParID;
