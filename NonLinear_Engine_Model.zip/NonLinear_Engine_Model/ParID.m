clc;
clearvars;
close all;

%% file description

% Parameter identification file used for the intake manifold exercise.
% Do not simply press F5 and look at the result. You might learn a lot from
% this file, so take 10 minutes and go through the m-file line by line and
% comment by comment. This will make it easier for you and also for us.

%% Load identification data:
    
load dynamic_0003 % DataIdentification

%% Initialising all the known parameters:
    
run Parameters;

%% Initial guess for parameters to be identified

alpha_0   = 3e-6;    % Initial guess for the manifold volume in [m^3]
alpha_1   = 6e-6;       % Initial guess for volumetric efficiency, speed dep. part, dimensionless
V_m       = 7e-3;
gamma_0     = 0.6;
gamma_1     = 0.002;
beta0       = 7;
eta0        = 0.3;
eta1        = -3e-4;
Theta_e     = 0.2;
% The initial guess should be values that roughly make sense. This improves
% the convergence of the fminsearch-algorithm.

par0 = [alpha_0, alpha_1, V_m, gamma_0, gamma_1, beta0, eta0, eta1, Theta_e]; % rewrite as vector to pass to fminsearch

%% Starting the optimization

% set optimization parameters. (type "optimset" into the command window to
% see all the possible settings you can make)
opt_options = optimset('TolFun',1e-4,'TolX',1e-4,'MaxIter',200,'MaxFunEvals',2000,'Display','iter');

% start fminsearch
% Runs the file "Modelerror" with these parameters, options and data
errorfnc_fminsearch = @(par0) Modelerror(par0, meas, par, 'Parameter Identification');
tic
optpar = fminsearch(errorfnc_fminsearch, par0, opt_options);
opt_dur = toc;
    
alpha_0_opt     = optpar(1);
alpha_1_opt     = optpar(2);
V_m_opt         = optpar(3);
gamma_0_opt     = optpar(4);
gamma_1_opt     = optpar(5);
beta0_opt       = optpar(6);
eta0_opt        = optpar(7);
eta1_opt        = optpar(8);
Theta_e_opt     = optpar(9);

% some plots are made within the Modelerror.m-file. Close them after
% fminsearch has terminated
close all 

% Display the identified parameter values (in 2 different ways)
fprintf('Parameter identification duration: %1.1f seconds\n\n',opt_dur);
fprintf('\n\n\nFMINSEARCH: IDENTIFIED PARAMETER VALUES\n');
fprintf('alpha_0 = %1.9f\n', optpar(1)) % \n means new line, 1.5f means float variable and 5 decimals displayed
fprintf('alpha_1 = %1.9f\n', optpar(2))
fprintf('V_m = %1.5f\n', optpar(3)) % \n means new line, 1.5f means float variable and 5 decimals displayed
fprintf('gamma_0 = %1.5f\n', optpar(4)) % \n means new line, 1.5f means float variable and 5 decimals displayed
fprintf('gamma_1 = %1.5f\n', optpar(5))
fprintf('beta0 = %1.5f\n', optpar(6)) % \n means new line, 1.5f means float variable and 5 decimals displayed
fprintf('eta0 = %1.5f\n', optpar(7))
fprintf('eta1 = %1.5f\n', optpar(8)) % \n means new line, 1.5f means float variable and 5 decimals displayed
fprintf('Theta_e = %1.5f\n', optpar(9))


%% Validation: compare the simulation (using the identified parameters) with the validation data

% load validation data
S = load('dynamic_0002.mat');
Val_meas = S.meas;
% evaluate model
par.enablePlot = 1;
Modelerror([alpha_0_opt, alpha_1_opt, V_m_opt, gamma_0_opt, gamma_1_opt, beta0_opt, eta0_opt, eta1_opt, Theta_e_opt], Val_meas, par, 'Evaluation on Validation Data');
% you can simply use the plot commands which you already wrote in the 
% Modelerror file. As inputs, the identified optimal parameters are used.


