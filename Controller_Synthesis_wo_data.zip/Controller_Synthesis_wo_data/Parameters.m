
%Parameters

if ~exist('par','var'); par = struct(); end

% Optima nur anlegen, wenn sie noch nicht existieren
if ~isfield(par,'Vm_opt');      par.Vm_opt = 0;      end
if ~isfield(par,'alpha_0_opt'); par.alpha_0_opt = 0; end
if ~isfield(par,'alpha_1_opt'); par.alpha_1_opt = 0; end
if ~isfield(par,'gamma_0_opt'); par.gamma_0_opt = 0; end
if ~isfield(par,'gamma_1_opt'); par.gamma_1_opt = 0; end
if ~isfield(par,'eta_0_opt'); par.eta_0_opt = 0; end
if ~isfield(par,'eta_1_opt'); par.eta_1_opt = 0; end
if ~isfield(par,'beta_0_opt'); par.beta_0_opt = 0; end
if ~isfield(par,'theta_e_opt'); par.theta_e_opt = 0; end




par.R           = 287;
par.Vd          = 2.48e-3;
par.Vc          = 2.48e-4;
par.sigma_0     = 14.7;
par.kappa       = 1.35;
par.Hl          = 42.5e6;
par.k_zeta      = 2.3345e-4;
par.eta_gen     = 0.7;
par.lambda      = 1;

par.omega_e_max = 500;
par.omega_e_min = 20;


%Parameters to be identified
par.alpha_0_init    = 3e-6;
par.alpha_1_init    = 6e-6;
par.Vm_init         = 7e-3;
par.gamma_0_init    = 0.6;
par.gamma_1_init    = 0.002;
par.eta_0_init      = 0.3;
par.eta_1_init      = -3e-4;
par.beta_0_init     = 7;
par.theta_e_init    = 0.2;


par.alpha_0 = par.alpha_0_opt + (par.alpha_0_opt == 0) * par.alpha_0_init;
par.alpha_1 = par.alpha_1_opt + (par.alpha_1_opt == 0) * par.alpha_1_init;
par.gamma_0 = par.gamma_0_opt + (par.gamma_0_opt == 0) * par.gamma_0_init;
par.gamma_1 = par.gamma_1_opt + (par.gamma_1_opt == 0) * par.gamma_1_init;
par.Vm = par.Vm_opt + (par.Vm_opt == 0) * par.Vm_init;
par.eta_0 = par.eta_0_opt + (par.eta_0_opt == 0) * par.eta_0_init;
par.eta_1 = par.eta_1_opt + (par.eta_1_opt == 0) * par.eta_1_init;
par.beta_0 = par.beta_0_opt + (par.beta_0_opt == 0) * par.beta_0_init;
par.theta_e = par.theta_e_opt + (par.theta_e_opt == 0) * par.theta_e_init;


%From Workspace
data1 = load('ISCSData/quasistatic_0001');
data2 = load('ISCSData/dynamic_0003');
data3 = load('ISCSData/dynamic_0002');
data_stud_1 = load('ISCSData/studentId_0009');
data_stud_2 = load('ISCSData/studentId_0010');

Data = data3.meas; % Choose of dataset

%fieldnames(Data)  % Show Content of Data


%cont_out        = Data.cont_out;
%omega_e_deired  = Data.omega_e_desired;
%I_Gen           = Data.I_Gen;
%U_Bat           = Data.U_Bat;

%Optimal Parameters from PARID
par.alpha_0_opt     = 0.000001688;
par.alpha_1_opt     = 0.000005719;
par.V_m_opt         = 0.00549;
par.gamma_0_opt     = 0.67534;
par.gamma_1_opt     = 0.00090;
par.beta0_opt       = 14.70286;
par.eta_0_opt       = 0.41367;
par.eta_1_opt       = -0.00022;
par.theta_e_opt     = 0.18449;


% Initial value of the Integrators
par.p_m_init = Data.p_m.signals.values(1);
par.omega_e_init = Data.omega_e.signals.values(1);
par.end_time = Data.omega_e.time(end);
par.du_ign_zero = Data.du_ign.signals.values(1);


par.simopt = simset('Solver','ode1','FixedStep',1e-3,'SrcWorkspace','current');

par.model = 'Norm_Engine_model'; %choose model
par.enablePlot = 1;


%% === Operating point from studentId_0009 ===
par.u_alpha0   = 2.82828;
par.du_zeta0   = 0;
par.u_l0       = 1;
par.P_l0       = 1146.78;
par.p_a0       = 94219.8;
par.p_e0       = 97223.1;
par.T_a0       = 294.25;
par.T_m0       = 304.35;
par.omega_zero = 124.339;
par.p_zero     = 24504.4;

omega_e0 = 124.34;
p_m0     = 31399.27; 

assignin('base', 'par', par);
