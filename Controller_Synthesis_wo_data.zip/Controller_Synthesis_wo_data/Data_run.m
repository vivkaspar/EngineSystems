%% Load and plot all datasets

files = { ...
    'quasistatic_0001', ...
    'dynamic_0003', ...
    'dynamic_0002', ...
    'studentId_0009', ...
    'studentId_0010'};

for k = 1:numel(files)
    S  = load(fullfile('ISCSData', files{k}));

    % unwrap top-level struct to get the "sig" struct
    fnTop = fieldnames(S);
    sig   = S.(fnTop{1});

    % plot all signals in this dataset
    plot_all_signals(sig, files{k});
end

%% -------- Helper function (same file, after the script) ----------
function plot_all_signals(sig, datasetName)

    % time vector if present
    if isfield(sig, 'time') && isnumeric(sig.time)
        t = sig.time(:);
    else
        t = [];
    end

    fNames = fieldnames(sig);

    for i = 1:numel(fNames)
        name = fNames{i};
        % --- FILTER: show only one signal ---
        if ~strcmp(name, 'omega_e')    % ← change 'omega_e' to whatever you want
            continue;
        end

        s   = sig.(name);
        val = [];

        if isstruct(s)
            if isfield(s, 'signals') && isfield(s.signals, 'values')
                val = s.signals.values;
            elseif isfield(s, 'values')
                val = s.values;
            elseif isfield(s, 'data')
                val = s.data;
            else
                subF = fieldnames(s);
                for jj = 1:numel(subF)
                    cand = s.(subF{jj});
                    if isnumeric(cand)
                        val = cand;
                        break;
                    end
                end
            end
        elseif isnumeric(s)
            val = s;
        end

        if isempty(val) || ~isnumeric(val)
            continue;
        end

        val = squeeze(val);

        figure;
        if ~isempty(t) && size(val,1) == numel(t)
            plot(t, val, 'LineWidth', 1.2);
            xlabel('time');
        else
            plot(val, 'LineWidth', 1.2);
            xlabel('sample');
        end
        grid on;
        title(sprintf('%s - %s', datasetName, name), 'Interpreter', 'none');
        ylabel('value');
    end
end
