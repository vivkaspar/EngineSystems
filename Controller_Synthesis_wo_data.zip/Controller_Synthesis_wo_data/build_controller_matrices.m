
%% ==== Build final ISCS controller matrices (continuous & discrete) ====

% Use extended plant for controller synthesis
A_x = A_ext;      % n_ext x n_ext
B_x = B_ext;      % n_ext x 2
C_x = C_ext;      % 1 x n_ext
% D_ext not needed here

K = K_ext;      % 2 x n_ext   (LQR gain)
L = L_ext;      % n_ext x 1   (observer gain)

n  = size(A_x,1);   % n_ext
nu = size(B_x,2);   % 2 inputs

% --- Extension matrices (integrator on speed error) ---
Ae = 0;                  % scalar
Be = [1 0];              % 1 x 2
Ce = [KI; 0];            % 2 x 1
De = eye(2);             % 2 x 2

%% 1) Continuous-time ISCS controller (from manual eqs.)

% A_c (controller state = [v; x_hat], size (1+n) x (1+n))
ISCSAc = [ Ae              -Be*K ;            % 1 x 1 | 1 x n
           zeros(n,1)  A_x - B_x*K - L*C_x ];       % n x 1 | n x n

% B_c  (input is measured output y, scalar)
% sign chosen so that input = y - r in Simulink (r enters separately)
ISCSBc = [ 0 ;            % 1 x 1
          -L ];           % n x 1

% C_c  (2 outputs: [u_alpha_norm; du_ign_norm])
ISCSCc = [ Ce   -De*K ];  % 2 x (1+n)

% D_c (2 x 1) – zero for LQG
ISCSDc = zeros(2,1);

%% 2) Discretise controller

Ts = 1e-3;   % controller sampling time [s]

Ccont = ss(ISCSAc, ISCSBc, ISCSCc, ISCSDc);
Cdisc = c2d(Ccont, Ts, 'tustin');

[ISCS_Ad, ISCS_Bd, ISCS_Cd, ISCS_Dd] = ssdata(Cdisc);
ISCS_Dd_test = [0;0];   % enforce exact zero feedthrough

%% 3) Scaling matrices (physical <-> normalised)

% Input scaling: [u_alpha; du_ign] = ISCS_Tu * [u_alpha_norm; du_ign_norm]
ISCS_Tu = [u_alpha_nom  0;
           0            du_ign_nom];

% Output scaling: omega_norm = omega_e / ISCS_Ty
ISCS_Ty = omega_nom;

%% 4) Save everything for Simulink controller model

save('Controller130.mat', ...
     'ISCS_Ad','ISCS_Bd','ISCS_Cd','ISCS_Dd', ...
     'ISCS_Tu','ISCS_Ty');

disp('Controller matrices and scaling saved to ControllerX.mat');
