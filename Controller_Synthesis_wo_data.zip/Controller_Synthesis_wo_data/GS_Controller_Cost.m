%% =====================================================================
%  Grid search for LQGI idle speed controller (ETH ISCS exercise)
%  - Builds linear plant from normalized Pade model
%  - Designs LQGI controller for each (KI, Qspeed, Qint, r1, r2, q)
%  - Checks wcg <= 4 rad/s and µ >= 0.5 BEFORE nonlinear sim
%  - Simulates nonlinear engine + controller
%  - Evaluates competition cost function J
%  - Saves best controller as Controller_best.mat
% =======================================================================
clear; clc; close all;

%% -----------------------------------------------------------------------
%  0) User settings: parameter grids & model names
% ------------------------------------------------------------------------
% Grids
KI_grid     = [5.0 5.5 6.0];          % integral gain on throttle channel
Qspeed_grid = [35 40 45];      % Q_ext(1,1) (speed state)
Qint_grid   = [40 45 50];     % Q_ext(end,end) (integrator/extension state)
r1_grid     = [10 12 15 17];       % throttle weight in R
r2_grid     = [30 35];   % ignition weight in R
q_grid      = [0.25 0.5 0.75];        % observer tuning

RMSE_max    = 0.20;             % max allowed normalized RMSE

% Simulink models
plantNormModel = 'Pade_Norm_Engine_model_m3';
clModel        = 'Pade_Norm_Engine_model_Controller';

% Controller sampling time
Ts = 1e-3;   % [s]

%% -----------------------------------------------------------------------
%  1) Nominal operating point and linear plant (10 states, 2 in, 1 out)
% ------------------------------------------------------------------------
run Parameters.m

opts.u_alpha_pct_tol = 2.5;
opts.du_ign_deg_tol  = 10.0;
opts.domega_dt_tol   = 20.0;
opts.min_window_s    = 0.5;
opts.smooth_win      = 21;
opts.plot            = false;

op = m3_pick_idle_op('ISCSData/dynamic_0003', 2.0, opts);

omega_nom   = op.omega_e_rads;   % [rad/s]
u_alpha_nom = op.u_alpha_pct;    % [%]
du_ign_nom  = -5;               % [deg CA]

m_beta_nom  = op.mdot_beta;      % [kg/s]
u_IPS_nom   = m_beta_nom / omega_nom;

% Nominal delays
tau_IPS_nom = 2*pi / omega_nom;
tau_seg_nom = 4*pi / (5*omega_nom);
tau_ign_nom = tau_seg_nom / 2;

% 4th-order Padé blocks
order = 4;
[A_IPS,B_IPS,C_IPS,D_IPS,x0_IPS] = makePadeBlock(tau_IPS_nom, u_IPS_nom, order);
[A_ign,B_ign,C_ign,D_ign,x0_ign] = makePadeBlock(tau_ign_nom, du_ign_nom, order);

% Short sim for steady state of normalized model
simopt = simset('Solver','ode1','FixedStep',1e-3,'SrcWorkspace','current');
sim(plantNormModel, 5, simopt);

% Linearization around normalized steady state
x0 = [1; 1; x0_IPS(:); x0_ign(:)];
u0 = [1; 1];                       % [u_alpha_norm; du_ign_norm]
[A,B,C,D] = linmod(plantNormModel, x0, u0);
fprintf('Eigenvalues of A:\n'); disp(eig(A).');

P  = ss(A,B,C,D);
As = A; Bs = B; Cs = C; Ds = D;

fprintf('cond(A) = %.2e\n', cond(A));
save('EngineLinearModel.mat','A','B','C','D','P');

%% -----------------------------------------------------------------------
%  2) Predefine cost function constants & scaling
% ------------------------------------------------------------------------
k_zeta         = 2.3345e-4;      % [1/(deg^2 CA)]
Delta_zeta_nom = du_ign_nom;     % [deg CA]
kmax           = 1 / (1 - k_zeta * Delta_zeta_nom^2);
w_speed        = 0.2 * kmax / 2.5;

% Scaling matrices (physical <-> normalized)
ISCS_Tu = [u_alpha_nom  0;
           0            du_ign_nom];
ISCS_Ty = omega_nom;

% Common Simulink SimulationInput
Tsim  = 90; % [s]
simIn = Simulink.SimulationInput(clModel);
simIn = setModelParameter(simIn,'StopTime',num2str(Tsim));
simIn = setModelParameter(simIn,'ReturnWorkspaceOutputs','on');

%% -----------------------------------------------------------------------
%  3) Grid search
% ------------------------------------------------------------------------
candIdx  = 0;
bestJ    = inf;
bestInfo = struct();
results  = [];

for KI = KI_grid
  for Qspeed = Qspeed_grid
    for Qint = Qint_grid
      for r1 = r1_grid
        for r2 = r2_grid
          for q = q_grid
            candIdx = candIdx + 1;
            fprintf('\n=== Candidate %d: KI=%.3g, Qspeed=%.3g, Qint=%.3g, r1=%.3g, r2=%.3g, q=%.3g ===\n',...
                    candIdx, KI, Qspeed, Qint, r1, r2, q);

            J   = inf;
            RMSE = NaN;
            mu   = NaN;
            wcg  = NaN;

            try
              % --- 3.1 Design LQGI controller for this parameter set -----
              [ISCSAc,ISCSBc,ISCSCc,ISCSDc, ...
               ISCS_Ad,ISCS_Bd,ISCS_Cd,ISCS_Dd, ...
               A_ext,B_ext,C_ext,D_ext, ...
               K_ext,L_ext] = design_LQGI(As,Bs,Cs,Ds,KI,Qspeed,Qint,r1,r2,q,Ts);

              % Continuous-time controller for loop-shaping checks
              Ccont = ss(ISCSAc,ISCSBc,ISCSCc,ISCSDc);

              % --- 3.2 Open-loop L(s) = P(s)C(s) and crossover check ----
              L_open = P * Ccont;          % error -> omega_norm
              [GM,PM,wcg,wcp] = margin(L_open); %#ok<ASGLU>

              if isempty(wcg) || isnan(wcg)
                fprintf('   wcg undefined -> rejected\n');
                wcg = NaN;
              elseif wcg > 4
                fprintf('   wcg = %.3f rad/s > 4 -> rejected\n', wcg);
              else
                % --- 3.3 Return difference µ via sensitivity S ----------
                S = feedback(1,L_open);    % S = 1/(1+L)
                [mag,~,w] = bode(S); %#ok<ASGLU>
                mag = squeeze(mag);
                mu  = 1 / max(mag);
                fprintf('   wcg = %.3f rad/s, µ = %.3f\n', wcg, mu);

                if mu < 0.5
                  fprintf('   µ < 0.5 -> rejected\n');
                else
                  % --- 3.4 Nonlinear Simulink simulation ----------------
                  assignin('base','ISCSAc', ISCSAc);
                  assignin('base','ISCSBc', ISCSBc);
                  assignin('base','ISCSCc', ISCSCc);
                  assignin('base','ISCSDc', ISCSDc);
                  assignin('base','ISCS_Ad',ISCS_Ad);
                  assignin('base','ISCS_Bd',ISCS_Bd);
                  assignin('base','ISCS_Cd',ISCS_Cd);
                  assignin('base','ISCS_Dd',ISCS_Dd);
                  assignin('base','ISCS_Tu',ISCS_Tu);
                  assignin('base','ISCS_Ty',ISCS_Ty);

                  simOut = sim(simIn);

                    % --- 3.5 Cost and RMSE --------------------------------
                    [J,RMSE] = eval_cost_from_sim(simOut,ISCS_Ty,ISCS_Tu(1,1),w_speed);
                    fprintf('   J = %.4g, RMSE(norm) = %.3f\n', J, RMSE);
                    
                    % RMSE requirement
                    if RMSE > RMSE_max
                      fprintf('   RMSE = %.3f > %.3f -> rejected\n', RMSE, RMSE_max);
                      J = inf;   % mark as unworthy
                    end
                end
              end

            catch ME
              warning('   Candidate failed: %s', ME.message);
              J = inf; RMSE = NaN; mu = NaN; wcg = NaN;
            end

            % Store result
            results(candIdx).u_alpha_nom = u_alpha_nom;
            results(candIdx).du_ign_nom = du_ign_nom;
            results(candIdx).KI     = KI;
            results(candIdx).Qspeed = Qspeed;
            results(candIdx).Qint   = Qint;
            results(candIdx).r1     = r1;
            results(candIdx).r2     = r2;
            results(candIdx).q      = q;
            results(candIdx).J      = J;
            results(candIdx).RMSE   = RMSE;
            results(candIdx).mu     = mu;
            results(candIdx).wcg    = wcg;

            % Update best (only finite J)
            if isfinite(J) && (J < bestJ)
              bestJ    = J;
              bestInfo = results(candIdx);
              bestCtrl.ISCS_Ad = ISCS_Ad;
              bestCtrl.ISCS_Bd = ISCS_Bd;
              bestCtrl.ISCS_Cd = ISCS_Cd;
              bestCtrl.ISCS_Dd = ISCS_Dd;
              bestCtrl.ISCS_Tu = ISCS_Tu;
              bestCtrl.ISCS_Ty = ISCS_Ty;
              fprintf('   -> NEW BEST, J = %.4g\n', J);
            end

          end % q
        end % r2
      end % r1
    end % Qint
  end % Qspeed
end % KI

%% -----------------------------------------------------------------------
%  4) Save best controller
% ------------------------------------------------------------------------
if isfinite(bestJ)
  save('Controller_best.mat','-struct','bestCtrl');
  fprintf('\nBest controller:\n');
  disp(bestInfo);
  fprintf('Saved as Controller_best.mat\n');
else
  warning('No controller satisfying wcg <= 4 and µ >= 0.5 was found.');
end

%% =======================================================================
%  Local functions
% =======================================================================

function [ISCSAc,ISCSBc,ISCSCc,ISCSDc, ...
          ISCS_Ad,ISCS_Bd,ISCS_Cd,ISCS_Dd, ...
          A_ext,B_ext,C_ext,D_ext, ...
          K_ext,L_ext] = design_LQGI(As,Bs,Cs,Ds,KI,Qspeed,Qint,r1,r2,q,Ts)
% Build extended plant, design LQR and observer, build cont. & disc. ISCS.

  % --- Extended plant with integrator on speed error --------------------
  Ae = 0;
  Be = [1 0];
  Ce = [KI; 0];
  De = [1 0; 0 1];

  A_ext = [As,              Bs*Ce;
           zeros(1,size(As,1)), Ae];
  B_ext = [Bs*De;
           Be];
  C_ext = [Cs, Ds*Ce];
  D_ext = Ds*De;

  nx_ext = size(A_ext,1);

  % --- LQR weights ------------------------------------------------------
  Q_ext = eye(nx_ext);
  Q_ext(1,1)          = Qspeed;  % speed state
  Q_ext(nx_ext,nx_ext) = Qint;   % integrator/extension state
  R = diag([r1, r2]);

  [K_ext,~,~] = lqr(A_ext,B_ext,Q_ext,R);

  % --- Observer via dual LQR -------------------------------------------
  L_ext = lqr(A_ext',C_ext',B_ext*B_ext',q)';

  % --- Continuous-time ISCS controller matrices ------------------------
  A_x = A_ext;
  B_x = B_ext;
  C_x = C_ext;
  K   = K_ext;
  L   = L_ext;
  n   = size(A_x,1);

  ISCSAc = [ Ae              -Be*K;
             zeros(n,1)  A_x - B_x*K - L*C_x ];

  ISCSBc = [0;
            -L];

  ISCSCc = [Ce  -De*K];
  ISCSDc = zeros(2,1);

  % --- Discretize with Tustin ------------------------------------------
  Ccont = ss(ISCSAc,ISCSBc,ISCSCc,ISCSDc);
  Cdisc = c2d(Ccont,Ts,'tustin');
  [ISCS_Ad,ISCS_Bd,ISCS_Cd,ISCS_Dd] = ssdata(Cdisc);
  ISCS_Dd(:) = 0;   % enforce zero feedthrough
end

function [J,RMSE] = eval_cost_from_sim(simOut,ISCS_Ty,u_alpha_nom,w_speed)
% Extract signals from logsout and compute cost J and RMSE.

  logs = simOut.logsout;

  % Adjust indices if your logsout ordering is different
  uSig  = logs{1};  % [u_alpha_norm, du_ign_norm]
  ySig  = logs{2};  % omega_norm
  rSig  = logs{3};  % omega_norm_ref

  t_omega  = ySig.Values.Time;
  omega_n  = ySig.Values.Data;          % normalized
  omega_rn = rSig.Values.Data;

  t_u       = uSig.Values.Time;
  u_data    = uSig.Values.Data;
  u_alpha_n = u_data(:,1);              % normalized throttle

  % Physical
  omega   = omega_n  * ISCS_Ty;
  omega_r = omega_rn * ISCS_Ty;
  u_alpha = u_alpha_n * u_alpha_nom;

  % RMSE in normalized units
  err_n = omega_rn - omega_n;
  RMSE  = sqrt(mean(err_n.^2));

  % Throttle rate du_alpha/dt
  du_dt = gradient(u_alpha, t_u);       % [%/s]
  du_dt_omega = interp1(t_u, du_dt, t_omega, 'linear', 'extrap');

  % Cost integrand
  integrand = w_speed * abs(omega - omega_r) + abs(du_dt_omega);

  J = trapz(t_omega, integrand);
end
