clc
run Parameters.m

opts.u_alpha_pct_tol = 2.5;   % ±1% around target (was 0.3)
opts.du_ign_deg_tol  = 10.0;   % |du_ign| ≤ 2 deg (was 0.5)
opts.domega_dt_tol   = 20.0;   % |dω/dt| ≤ 2.5 rad/s^2 (was 0.8)
opts.min_window_s    = 0.5;   % only 0.5 s contiguous (was 1.0)
opts.smooth_win      = 21;    % more smoothing on dω/dt
opts.plot            = true;

op = m3_pick_idle_op('ISCSData/dynamic_0003', 2.0, opts);

omega_nom   = op.omega_e_rads;     % [rad/s]  example idle speed, replace with your value
u_alpha_nom = op.u_alpha_pct;      % [%]      nominal throttle command (if needed elsewhere)
du_ign_nom = -5; % guard against 0 nominal input 

m_beta_nom  = op.mdot_beta;    % [kg/s]   example, replace with your value

u_IPS_nom   = m_beta_nom/ omega_nom;

%% === Compute nominal delay times ===
% From the engine torque block description:
%   τ_IPS = 2π / ω_e
%   τ_seg = 4π / (5 * ω_e)
tau_IPS_nom  = 2*pi / omega_nom;            % [s]
tau_seg_nom  = 4*pi / (5 * omega_nom);      % [s]
tau_ign_nom  = tau_seg_nom / 2;             % [s] delay acting on Δu_ζ

%% === Build 4th-order Padé blocks ===
order = 4;

% 1) IPS delay on ṁβ/ωe
[A_IPS,B_IPS,C_IPS,D_IPS,x0_IPS] = ...
    makePadeBlock(tau_IPS_nom, u_IPS_nom, order);
x0_IPS_test = [0;0;0;u_IPS_nom];

% 2) ignition delay on Δuζ
[A_ign,B_ign,C_ign,D_ign,x0_ign] = ...
    makePadeBlock(tau_ign_nom, du_ign_nom, order);
x0_ign_test = [0;0;0;du_ign_nom];

% 2) Steady-state check (short sim of normalized model)
simopt = simset('Solver','ode1','FixedStep',1e-3,'SrcWorkspace','current');  % as in manual
sim('Pade_Norm_Engine_model_m3', 5, simopt);   % <-- use your normalized model name

x0 = [1; 1; x0_IPS(:); x0_ign(:)];   % in correct state order
u0 = [1; 1];   % e.g. u_alpha_norm = 1, Δu_ign_norm = 0
[A,B,C,D] = linmod('Pade_Norm_Engine_model_m3', x0, u0);
eigA = eig(A);
disp('Eigenvalues of A:');
disp(eigA.');

P = ss(A,B,C,D);
disp('Continuous-time plant P:');
P;

% Condition number
kA = cond(A);
fprintf('cond(A) = %.2e\n', kA);

% 5) Save linear model for controller design
save('EngineLinearModel.mat','A','B','C','D','P');

% Original plant (your linmod result)
As = A;
Bs = B;
Cs = C;
Ds = D;

% Choose an integral gain KI (start with 1, tune later)
KI = 5.5;

% Extension matrices (eq. 2.6)
Ae = 0;
Be = [1 0];
Ce = [KI; 0];
De = [1 0; 0 1];

% Extended plant matrices (eqs. 2.8–2.9)
A_ext = [As,        Bs*Ce;
         zeros(1,size(As,1)), Ae];

B_ext = [Bs*De;
         Be];

C_ext = [Cs, Ds*Ce];

D_ext = Ds*De;

% This extended plant is what you use for LQR/LQG design in the next steps:
P_ext = ss(A_ext, B_ext, C_ext, D_ext);

%% design_LQR_ext.m
% Assumes P_ext (extended plant) is in the workspace

% Extract matrices of extended plant
%[A_ext, B_ext, C_ext, D_ext] = ssdata(P_ext);

nx_ext = size(A_ext,1);   % states of extended plant
nu     = size(B_ext,2);   % 2 inputs (throttle, ignition)

fprintf('Extended plant: nx_ext = %d, nu = %d\n', nx_ext, nu);

%% Choose Q and R for LQR on extended plant

% Heuristic choice: penalize engine speed and integral channel strongly,
% lighter penalty on the Padé states.

% State weighting
Q_ext = diag([ ...
    35, ...  % x1  (normalized speed) - important
    1, 1, 1, 1, 1, 1, 1, 1, 1, ...  % rest of original 10+? states
    45 ...  % last state = extension/integrator-like part (v)
]);

% Input weighting (throttle cheaper than ignition)
R = diag([15, 35]);   % u1 = throttle, u2 = ignition

%% Continuous-time LQR

[K_ext, S_ext, eig_cl_ext] = lqr(A_ext, B_ext, Q_ext, R);

fprintf('norm(K_th)  = %.3e\n', norm(K_ext(1,:)));
fprintf('norm(K_ign) = %.3e\n', norm(K_ext(2,:)));

fprintf('LQR gain K_ext (size %dx%d):\n', size(K_ext,1), size(K_ext,2));
disp(K_ext);

fprintf('Closed-loop poles of extended plant:\n');
disp(eig_cl_ext.');

% Split K_ext into parts if needed later:
% K_ext = [K_states  K_v]
% where K_states acts on original plant states and K_v on the extension state
K_states = K_ext(:, 1:(nx_ext-1));    % all but last state
K_v      = K_ext(:, nx_ext);         % last column

fprintf('K_states (on original/plant states):\n');
disp(K_states);
fprintf('K_v (on extension state):\n');
disp(K_v);

nx_ext = size(A_ext,1);

% ---- choose observer tuning parameter q ----
q = 0.75;   % start with something like 1, 10, 100 and adjust

% L = lqr(A', C', B*B', q)'  (manual's formula)
L_ext = lqr(A_ext', C_ext', B_ext*B_ext', q)';

fprintf('Observer gain L_ext (size %dx%d):\n', size(L_ext,1), size(L_ext,2));
disp(L_ext);

% Closed-loop poles of observer error dynamics: A_ext - L_ext*C_ext
eig_obs = eig(A_ext - L_ext*C_ext);
fprintf('Observer poles (A_ext - L_ext*C_ext):\n');
disp(eig_obs.');

% Compare largest real parts to system poles A_ext - B_ext*K_ext
eig_cl_ext = eig(A_ext - B_ext*K_ext);   % from previous step (or recompute)
max_real_sys = max(real(eig_cl_ext));
max_real_obs = max(real(eig_obs));

fprintf('Max real part closed-loop (system)  : %.3f\n', max_real_sys);
fprintf('Max real part observer (A-LC)      : %.3f\n', max_real_obs);
fprintf('Ratio |Re(lambda_obs)| / |Re(lambda_sys)| ≈ %.2f\n', ...
        abs(max_real_obs)/abs(max_real_sys));
