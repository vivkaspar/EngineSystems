
% DEFINE INITIAL PARAMETERS FOR PARAMETER IDENTIFICATION AND LINEARIZATION

% Defining engine and environmental parameters:
par.cp          = 1003;             % [J/(kg*K)] Specific heat capacity at constant pressure.
par.cv          = 717;              % [J/(kg*K)] Specific heat capacity at constant volume.
par.kappa       = par.cp/par.cv;    % [-]        Heat capacity ratio or adiabatic index
par.epsilon     = 10;               % [-]        Compression Ratio
par.p_e         = 1e5;              % [Pa]       Pressure of the exhaust gas remaining in the cylinder.
par.R           = 287;              % [J/(kg*K)] Universal gas constant of air.
par.theta_in    = 295;              % [K]        Temperature of the air entering the intake manifold.
par.Vd          = 2.5e-3;           % [m^3]      Displacement volume of the engine
par.omega_e     = 125;              % [rad/s]    Engine speed
        
% These are the results of the parameter identification. It is used in the
% linearization file (currently initial guess)
par.theta_e_opt     = 0.2;          % [kg*m^2]     engine rotational inertia

% Model Initial conditions:
par.omega_e     = IdData.omega_e.signals.values(1); % [rad/s] initial value defined above, but may also be set via data

% Define Simulation Parameters. They are set for all "sim"-commands
par.sim_opt     = simset( 'SrcWorkspace','current','FixedStep',1e-3,'Solver','ode1'); 
% use a fixed step size, this is the same stepsize as in the measurement.
% Use current worspace option in order to let the simulation in the file
% modelerror look for parameters in its own workspace and not in the base
% matlab workspace.

%% Options

% Choose the model you want to simulate here:
par.ModNam = 'Engine_Inertia_layout';

% Set to 1 to create a figure in the modelerror file
par.enablePlot = 1;