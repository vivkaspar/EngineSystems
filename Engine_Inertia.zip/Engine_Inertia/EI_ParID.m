%%-------------------------------------------------------------
% Raffi Hedinger (hraffael@ethz.ch),                2012
% modified by Norbert Zsiga (nzsiga@ethz.ch),       02.10.2014
% modified by Raffi Hedinger,                       16.10.2017
% modified by Raffi Hedinger,                       09.10.2018
% modified by Pol Duhr (pduhr@ethz.ch),             16.08.2019
% modified by Johannes Ritzmann, (jritzman@ethz.ch) 25.09.2020
% modified by Marc Neumann, (mneumann@ethz.ch)      12.10.2022
% ETH Zurich, IDSC, Project: Engine Systems Exercise Class
%--------------------------------------------------------------

% clc;
% clearvars;
% close all;

%% file description

% Parameter identification file used for the intake manifold exercise.
% Do not simply press F5 and look at the result. You might learn a lot from
% this file, so take 10 minutes and go through the m-file line by line and
% comment by comment. This will make it easier for you and also for us.

%% Load identification data:
    
load DataIdentification

%% Initialising all the known parameters:
    
run EI_Parameters.m;
    
% Parameters.m is an m-file that is executed by this command. Put the
% cursor on the filename and press ctrl+d to open the file. In that file,
% parameters and simulation options are defined.

%% Initial guess for parameters to be identified

theta_e_init       = 0.2;    % Initial guess for engine rotational inertia [kg*m^2]
    
% The initial guess should be values that roughly make sense. This improves
% the convergence of the fminsearch-algorithm.

par0 = [theta_e_init]; % rewrite as vector to pass to fminsearch

%% Starting the optimization

% set optimization parameters. (type "optimset" into the command window to
% see all the possible settings you can make)
opt_options  = optimset('TolFun',1e-6,...
                        'TolX',1e-6,...
                        'MaxIter',40,...
                        'Display','iter');

% start fminsearch
% Runs the file "Modelerror" with these parameters, options and data
errorfnc_fminsearch = @(par0) Modelerror(par0, IdData, par, 'Parameter Identification');
tic
optpar = fminsearch(errorfnc_fminsearch, par0, opt_options); 
opt_dur = toc;
    
theta_e_opt  = optpar(1); 
    
% some plots are made within the Modelerror.m-file. Close them after
% fminsearch has terminated
close all 

% Display the identified parameter values (in 2 different ways)
fprintf('Parameter identification duration: %1.1f seconds\n\n',opt_dur);
fprintf('\n\n\nFMINSEARCH: IDENTIFIED PARAMETER VALUES\n');
fprintf('theta_e [kg*m^2]              = %1.5f\n', optpar(1)) % \n means new line, 1.5f means float variable and 5 decimals displayed

%% Validation: compare the simulation (using the identified parameters) with the validation data

% load validation data
load DataValidation.mat

% evaluate model
par.enablePlot = 1;
Modelerror([theta_e_opt], ValData, par, 'Evaluation on Validation Data');
% you can simply use the plot commands which you already wrote in the 
% Modelerror file. As inputs, the identified optimal parameters are used.


