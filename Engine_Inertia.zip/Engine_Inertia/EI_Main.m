%--------------------------------------------------------------
% Raffi Hedinger (hraffael@ethz.ch), 16.10.2017
% Marc Neumann (mneumann@ethz.ch), 03.10.2023
% ETH Zurich, IDSC, Project: Engine Systems Exercise Class
%--------------------------------------------------------------

clc;
clearvars;
close all;
% execute these three commands each time you run the main file to make sure
% you are not using some leftover data from the workspace

% use '%%' at the beginning of a line to give the file some structure

%% file description

% Main file used to run the parameter identification and the linearization
% of the intake manifold model.

%% Run parameter identification file
    
run ParID;

%% Run linearization file
    
run Linearization;