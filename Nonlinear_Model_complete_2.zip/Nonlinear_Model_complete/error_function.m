function V = error_function(par, p_m, mdot_in,options)

% This is the so called 'error function' (modellguete.m) that is used in 
% combination with fminsearch.

% Set global optimization variables
%     global tau beta
Parameters;

p_meas = p_m;


% Assign new parameter values (used in Simulink model SystemModel.slx)
    Vm = par(1);


    

% Run simulation to determine the quality of the parameter values    
    [tsim,~,psim] = sim( 'NonlinearModel_complete_2', mdot_in.Time, options.sim_options );



% Calculate objective function
    V = sum((p_meas.signals.values-psim).^2);

% plot curves
if options.enablePlot
    figure(options.fig_num);
    plot(p_meas.time, p_meas.signals.values, 'b'); hold on; grid on;
    plot(tsim, psim, '-r' ); hold off;
    xlabel('Time [s]');
    ylabel('Model Ooutput [-]');
	legend({'Measurements','Simulation'},'Location','NorthEast')
    set(gca,'XLim',[p_meas.time(1) p_meas.time(end)]);
    set(gca,'YLim',[min(p_meas.signals.values)-1/10*mean(p_meas.signals.values) max(p_meas.signals.values)+1/10*mean(p_meas.signals.values)]);
    drawnow;
end