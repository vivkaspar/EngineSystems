% Example script for dynamic parameter iderntification
% Engine Systems Class, IDSC, ETH Zurich
clear; close all; clc;
Parameters;

%open_system('Model_excercise_1');
%disp('model_works')

% Set simulation options. The simset options are a command-based way to 
% define the simulation options. An alternative is to set them in the 
% simulink model itself. Using simset and applying the same options to all 
% simulations through the options-input in the "sim"-command is a way to 
% make sure all simulations use the same options.
    options.sim_options = simset('SrcWorkspace','current');
    
% Load measurement data for parameter identification and add it to
% fmin_data sruct

    data2 = load('ISCSData/dynamic_0003.mat');
    Vm = Vm0;
   

    out = sim('NonlinearModel_complete_2');
    mdot_in = out.mdot_in;
    whos mdot_in
    mdot_in_time  = mdot_in.Time;
    mdot_in_values = mdot_in.Data;



    p_m  = data2.meas.p_m;            % Structure with time
    p_meas_time   = p_m.time(:);
    p_meas_values  = p_m.signals.values(:);
    %p_zero = p_meas_values(1);

    % Display measurement values
    figure;
    subplot(2,1,1);
    plot(mdot_in_time, mdot_in_values);
        xlabel('Time [s]');
        legend({'mdot_{in}'},'Location','NorthWest');
    subplot(2,1,2);
    plot(p_meas_time,p_meas_values);
        xlabel('Time [s]');
        legend({'p_{meas}'},'Location','NorthWest');

       %% 
       
% Find the number of open figures, so a new figure can be created and used
% over and over again. This command is not necessarily needed but it is
% nice to have.
    fh=findall(0,'type','figure');
    options.fig_num = length(fh)+1;
    options.enablePlot = 1;

% Define starting values of the optimization variables.
    par0 = Vm0;



% Run fminsearch using the error function and find optimal parameter values      
    % Define function with only one input (parameters to be optimized)
        errorfnc_fminsearch = @(par0) error_function(par0, p_m, mdot_in, options);



    % Call fminsearch    
        opt_options = optimset('Algorithm','sqp','display','iter','Maxit',30);
        optpar = fminsearch(errorfnc_fminsearch, par0, opt_options);
       


% Extract optimal parameter values                    
    Vm = optpar(1);

fprintf('optimal Vm       = %.6f\n', Vm);

 

% Load validation data
    data3 = load('ISCSData/dynamic_0002.mat');

% Run a simulation with the identified optimal variable values
    mdot_in = ValData.mdot_in;
    p_meas = ValData.p;
    [tValSim,~,pvalsim] = sim('NonlinearModel_complete_2', ValData.mdot_in.time, options.sim_options);

% Graphically represent the quality of the optimization routine
    figure;
    subplot(2,1,1);
    plot(tValSim, ValData.mdot_in.signals.values, ...
         tValSim, ValData.p.signals.values);
        xlabel('Time [s]');
        ylabel('Inputs');
        legend('mdot_{in}');
    subplot(2,1,2);
    plot(tValSim, ValData.p.signals.values, ...
        tValSim, pvalsim);
        xlabel('Time [s]');
        ylabel('Outputs');
        legend('Measured p','Modelled p')