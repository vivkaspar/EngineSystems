%EngineInertia Parameters
%clear all; close all; clc;
    data1 = load('ISCSData/quasistatic_0001.mat');
    data2 = load('ISCSData/dynamic_0003.mat');
    data3 = load('ISCSData/dynamic_0002.mat');
% Defining engine and environmental parameters:
par.cp          = 1003;             % [J/(kg*K)] Specific heat capacity at constant pressure.
par.cv          = 717;              % [J/(kg*K)] Specific heat capacity at constant volume.
par.kappa       = par.cp/par.cv;    % [-]        Heat capacity ratio or adiabatic index
par.epsilon     = 10;               % [-]        Compression Ratio
par.p_e         = 1e5;              % [Pa]       Pressure of the exhaust gas remaining in the cylinder.
par.R           = 287;              % [J/(kg*K)] Universal gas constant of air.
par.theta_in    = 295;              % [K]        Temperature of the air entering the intake manifold.
par.Vd          = 2.5e-3;           % [m^3]      Displacement volume of the engine
par.omega_e     = 125;              % [rad/s]    Engine speed
        
% These are the results of the parameter identification. It is used in the
% linearization file (currently initial guess)
%par.theta_e_opt     = 0.2;          % [kg*m^2]     engine rotational inertia
theta_e = 0.2;
% Model Initial conditions:
%par.omega_e     = IdData.omega_e.signals.values(1); % [rad/s] initial value defined above, but may also be set via data
par.omega_e     = 125;
% Define Simulation Parameters. They are set for all "sim"-commands
par.sim_opt     = simset( 'SrcWorkspace','current','FixedStep',1e-3,'Solver','ode1'); 
% use a fixed step size, this is the same stepsize as in the measurement.
% Use current worspace option in order to let the simulation in the file
% modelerror look for parameters in its own workspace and not in the base
% matlab workspace.

%% % Throttle Area Parameters

% Defining engine and environmental parameters:
par.cp          = 1003;             % [J/(kg*K)] Specific heat capacity at constant pressure.
par.cv          = 717;              % [J/(kg*K)] Specific heat capacity at constant volume.
par.kappa       = par.cp/par.cv;    % [-]        Heat capacity ratio or adiabatic index
par.epsilon     = 10;               % [-]        Compression Ratio
par.p_e         = 1e5;              % [Pa]       Pressure of the exhaust gas remaining in the cylinder.
par.R           = 287;              % [J/(kg*K)] Universal gas constant of air.
par.theta_in    = 295;              % [K]        Temperature of the air entering the intake manifold.
par.Vd          = 2.5e-3;           % [m^3]      Displacement volume of the engine
par.omega_e     = 125;              % [rad/s]    Engine speed
        
% These are the results of the parameter identification. It is used in the linearization file.
ParID_1;
par.alpha_0 = par.alpha_0_opt;     % tbd [m^2]
par.alpha_1 = par.alpha_1_opt;     % tbd [m^2]
par.alpha_0_init = 3e-6;          % tbd [m^2]
par.alpha_1_init = 6e-6;  

% Model Initial conditions:
par.A_alpha_init = 0; %IdData.A_alpha.signals.values(1); % [Pa] Initial condition for throttle state are first values of Data

% Define Simulation Parameters. They are set for all "sim"-commands
par.sim_opt = simset( 'SrcWorkspace','current','FixedStep',1e-3,'Solver','ode1'); 
% use a fixed step size, this is the same stepsize as in the measurement.
% Use current worspace option in order to let the simulation in the file
% modelerror look for parameters in its own workspace and not in the base
% matlab workspace.

%% Engine Torque Generation
%Parameters Engine Torque Generation
%fix
%simopt = simset('Solver','ode1','FixedStep',1e-3,'SrcWorkspace',
%'current');
par.Vd = 2.48e-3;
par.Hl = 42.5e6;
par.kc = 2.3345e-4;

%to be identified
par.eta_0 = 0.3;
par.eta_1 = -3e-4;
par.beta_0 = 7;

par.lambda = 1;


%not sure
par.sigma_0 = 1;

%% %Parameters Intake Manifold

par.R = 287;
Vm0 = 0.007;
p_zero = data1.meas.p_m.signals.values(1);



%% Eingine Air Mass Flow
par.R = 287;
par.Vd = 2.48e-3;  
par.Vc = 2.48e-4;
par.kappa = 1.35;
ParID_2;
par.gamma_0_init = 0.6;
par.gamma_1_init = 0.002;
par.sigma_0 = 14.7;
par_lambda = 1;
%% Throttle Air Mass Flow
par.R = 287;

%% Load Torque
par.n_gen = 0.7;

%% Load data from measurements

%fieldnames(data1.meas)
%fieldnames(data2.meas)
%fieldnames(data3.meas)

p_e = data1.meas.p_e;
p_a = data1.meas.p_a;
theta_a = data1.meas.T_a;
theta_m = data1.meas.T_m;
P_l = data1.meas.P_l;
u_alpha = data1.meas.u_alpha;
du_zeta = data1.meas.du_ign;
u_l = data1.meas.u_l;
mdot_alpha = data1.meas.m_dot_alpha;

omega_e_desired = data1.meas.omega_e_desired;

omega_e = data1.meas.omega_e;
p_m = data1.meas.p_m;
%disp(du_zeta.signals.values)



