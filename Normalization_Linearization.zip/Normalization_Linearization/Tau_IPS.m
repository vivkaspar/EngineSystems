% Tau_IPS.m
% 4th-order Pade approximation for the IPS delay

clear; clc;

% --- delay and Pade order ---
tau_IPS = 3.5e-5;      % [s] from scope/identification
n       = 4;           % 4th order

% --- Pade -> state space ---
[num_IPS, den_IPS] = pade(tau_IPS, n);
[A_IPS, B_IPS, C_IPS, D_IPS] = tf2ss(num_IPS, den_IPS);

fprintf('A_IPS =\n'); disp(A_IPS);
fprintf('B_IPS =\n'); disp(B_IPS);
fprintf('C_IPS =\n'); disp(C_IPS);
fprintf('D_IPS =\n'); disp(D_IPS);

% --- Try to get operating-point input u0_IPS from measurements (optional) ---
u0_IPS = [];
x0_IPS = zeros(size(A_IPS,1),1);   % default for normalized Δ-model

if exist('meas','var')
    % choose operating time (where load on and near desired omega)
    t_op = 33.234;  % your chosen point
    [~, idx] = min(abs(meas.time - t_op));

    m_dot_alpha_eq = meas.m_dot_alpha.signals.values(idx);
    omega_e_eq     = meas.omega_e.signals.values(idx);

    u0_IPS = m_dot_alpha_eq / omega_e_eq;   % signal that feeds the delay
    x0_IPS = -A_IPS \ (B_IPS * u0_IPS);

    fprintf('Using u0_IPS = %.4e for nonlinear-model IC\n', u0_IPS);
    fprintf('x0_IPS (for nonlinear model) =\n'); disp(x0_IPS);
else
    fprintf(['meas not in workspace -> using x0_IPS = 0 (incremental model).\n' ...
             'For linearized Δ-model this is exactly what you want.\n']);
end

% --- Optional: Bode check ---
G_true = tf(1, 1, 'InputDelay', tau_IPS);
G_pade = tf(num_IPS, den_IPS);

w = logspace(3, 6, 400);   % focus where this tiny delay matters

figure;
bode(G_true, G_pade, w); grid on;
legend('True delay', '4th-order Padé', 'Location','best');
title(sprintf('4th-Order Padé Approximation (tau = %.1e s)', tau_IPS));