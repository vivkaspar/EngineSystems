run('Parameters.m');   

% simulation settings
Tfinal = 30;         % [s] simulate long enough for settling
dt = 1e-3;
t = (0:dt:Tfinal)';

% constant input signals (timeseries)
Data.u_alpha = timeseries(par.u_alpha0 * ones(size(t)), t);
Data.du_zeta = timeseries(par.du_zeta0 * ones(size(t)), t);
Data.u_l     = timeseries(par.u_l0     * ones(size(t)), t);
Data.P_l     = timeseries(par.P_l0     * ones(size(t)), t);
Data.p_a     = timeseries(par.p_a0     * ones(size(t)), t);
Data.p_e     = timeseries(par.p_e0     * ones(size(t)), t);
Data.T_a     = timeseries(par.T_a0     * ones(size(t)), t);
Data.T_m     = timeseries(par.T_m0     * ones(size(t)), t);


% configure simulation
simIn = Simulink.SimulationInput('NonlinearModel');  % check name!
simIn = simIn.setVariable('par', par);
simIn = simIn.setVariable('Data', Data);

simIn = simIn.setModelParameter( ...
    'Solver',     'ode1', ...
    'FixedStep',   '1e-3', ...
    'StopTime',    num2str(Tfinal), ...
    'SrcWorkspace','current');

% run steady-state sim
disp('Running steady-state simulation...');
simOut = sim(simIn);
disp('✅ Done.');

% === Extract main output ===
p_m_ss = simOut.p_m_ss;

figure;
plot(p_m_ss.Time, p_m_ss.Data, 'b', 'LineWidth', 1.4);
xlabel('Time [s]');
ylabel('Manifold Pressure [Pa]');
title('Steady-State Simulation Result');
grid on;

% === Compute steady-state (equilibrium) mean ===
t_end  = p_m_ss.Time(end);
idx_ss = p_m_ss.Time > 0.8 * t_end;
p_m_eq = mean(p_m_ss.Data(idx_ss));
std_p_m = std(p_m_ss.Data(idx_ss));
fprintf('Steady-state manifold pressure: %.2f Pa\n', p_m_eq);

% === Access logsout signals ===
logsout = simOut.logsout;
disp('Available logged signals:');
disp(logsout.getElementNames);

omega_e  = logsout.getElement('omega_e').Values;
%u_alpha  = logsout.getElement('u_alpha').Values;

idx_ss = omega_e.Time > 0.8 * t_end;
omega_e_eq = mean(omega_e.Data(idx_ss));
std_omega_e = std(omega_e.Data(idx_ss));


%fprintf('Steady-state throttle input: %.2f %%\n', u_alpha_eq);

% === Estimate system time constant τ ===
y  = p_m_ss.Data;
t  = p_m_ss.Time;
y0 = y(1);
y_end = y(end);
y_63 = y0 + 0.63*(y_end - y0);

[~, idx_tau] = min(abs(y - y_63));
tau = t(idx_tau) - t(1);


fprintf('\n=== Steady-State Summary ===\n');
fprintf('Manifold pressure p_m_eq   = %.2f Pa\n', p_m_eq);
fprintf('Steady-state engine speed: %.2f ± %.4f rad/s\n', omega_e_eq, std_omega_e);
fprintf('System time constant τ     = %.3f s\n', tau);