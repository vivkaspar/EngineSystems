% Tau_seg.m
% 4th-order Padé approximation for the segment delay (τ_seg)

clear; clc;

% === Delay and Pade order ===
tau_seg = 0.83;     % [s] from your steady-state result earlier
n       = 4;        % 4th order approximation

% === Pade -> State-space form ===
[num_seg, den_seg] = pade(tau_seg, n);
[A_seg, B_seg, C_seg, D_seg] = tf2ss(num_seg, den_seg);

% === True delay and Padé TF for comparison ===
G_true = tf(1, 1, 'InputDelay', tau_seg);
G_pade = tf(num_seg, den_seg);

% === Frequency range (1e-1 to 1e2 rad/s is reasonable here) ===
w = logspace(-1, 2, 400);

% === Bode plot comparison ===
figure;
bode(G_true, G_pade, w);
grid on;
legend('True delay', '4th-order Padé', 'Location','best');
title(sprintf('4th-Order Padé Approximation (τ = %.2f s)', tau_seg));

% === Optional: explicit phase comparison ===
[~, phase_true, wout] = bode(G_true, w);
[~, phase_pade] = bode(G_pade, w);

phase_true = squeeze(phase_true);
phase_pade = squeeze(phase_pade);

figure;
semilogx(wout, unwrap(phase_true*pi/180)*180/pi, 'b', 'LineWidth', 1.6); hold on;
semilogx(wout, unwrap(phase_pade*pi/180)*180/pi, 'r--', 'LineWidth', 1.6);
xlabel('Frequency [rad/s]');
ylabel('Phase [deg]');
title('Phase of True Delay vs 4th-Order Padé (τ_{seg})');
legend('True delay', 'Padé approximation');
grid on;

% === Print matrices ===
disp('A_seg ='); disp(A_seg);
disp('B_seg ='); disp(B_seg);
disp('C_seg ='); disp(C_seg);
disp('D_seg ='); disp(D_seg);

% === Initial condition ===
x0_seg = zeros(size(A_seg,1),1);
disp('x0_seg ='); disp(x0_seg);