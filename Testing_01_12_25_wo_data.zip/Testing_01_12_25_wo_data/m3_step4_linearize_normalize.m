function S = m3_step4_linearize_normalize(model)
if nargin < 1
    model = 'Pade_Engine_model';
end

op  = evalin('base','op');
par = evalin('base','par');

% Set ICs to idle
par.p_m_init     = op.p_m_Pa;
par.omega_e_init = op.omega_e_rads;
assignin('base','par',par);

% I/O: throttle, ignition, and output from Engine Inertia
io(1) = linio([model '/u_alpha'],        1, 'input');
io(2) = linio([model '/du_ign'],         1, 'input');
io(3) = linio([model '/Engine Inertia'], 1, 'output');

opPoint = operpoint(model);

% Default options → minimal realization
linsys = linearize(model, opPoint, io);  

[A,B,C,D] = ssdata(linsys);
S.sys = linsys;
S.A = A; S.B = B; S.C = C; S.D = D;

fprintf('Linearized @ idle | DC gain = %.3f\n', dcgain(linsys));
fprintf('Raw poles (real parts): %s\n', mat2str(real(pole(linsys))',4));
end
