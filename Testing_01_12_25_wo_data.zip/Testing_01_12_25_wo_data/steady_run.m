%% Steady-state simulation of Pade_Engine_model_m3

model = 'Pade_Engine_model_m3';
load_system(model);

% ---- Steady inputs (edit these to your nominal values) ----
u_alpha_nom = 2.0;   % throttle nominal value
du_ign_nom  = -15;   % ignition offset nominal value

Tsim  = 40;                                    % [s]

%% Set up SimulationInput so we always get a SimulationOutput object
simIn = Simulink.SimulationInput(model);
simIn = setModelParameter(simIn,'StopTime',num2str(Tsim));
simIn = setModelParameter(simIn,'ReturnWorkspaceOutputs','on');

%% Run simulation
simOut = sim(simIn);

%% Extract signals from logsout by index
logs = simOut.logsout;

% ---- Get logged signals from logsout dataset ----
logsout    = simOut.logsout;           % assumes signal logging is enabled
du_ign_ts  = logsout{3}.Values;
u_alpha_ts = logsout{4}.Values;
omega_ts   = logsout{1}.Values;
du_ign_del = logsout{2}.Values;

% ---- Plot ----
figure;

subplot(3,1,1);
plot(du_ign_ts.Time, du_ign_ts.Data);
grid on;
title('Ignition delay du\_ign');
ylabel('du\_ign');

subplot(3,1,2);
plot(u_alpha_ts.Time, u_alpha_ts.Data);
grid on;
title('Throttle input u\_alpha');
ylabel('u\_alpha');

subplot(3,1,3);
plot(omega_ts.Time, omega_ts.Data);
grid on;
title('Engine speed \omega\_e');
ylabel('\omega\_e');
xlabel('Time [s]');
