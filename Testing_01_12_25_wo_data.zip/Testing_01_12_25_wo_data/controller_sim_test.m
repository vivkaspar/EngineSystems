model = 'Pade_Norm_Engine_model_Controller';  % change if needed
Tsim  = 90;                                    % [s]

%% Set up SimulationInput so we always get a SimulationOutput object
simIn = Simulink.SimulationInput(model);
simIn = setModelParameter(simIn,'StopTime',num2str(Tsim));
simIn = setModelParameter(simIn,'ReturnWorkspaceOutputs','on');

%% Run simulation
simOut = sim(simIn);

%% Extract signals from logsout by index
logs = simOut.logsout;

uSig   = logs{1};   % [u_alpha, du_ign]
urSig  = logs{7};
duSig  = logs{3};
rSig   = logs{6};   % omega_norm_ref
ySig   = logs{3};   % omega_e_norm
ign_in  = logs{5}.Values.Data;
t_ign   = logs{5}.Values.Time;


t       = ySig.Values.Time;
t_u     = uSig.Values.Time;
t_ur    = urSig.Values.Time;
t_du    = duSig.Values.Time;
t_ref   = rSig.Values.Time;

omega   = ySig.Values.Data;        % scalar
omega_r = rSig.Values.Data;        % scalar

u_data  = uSig.Values.Data;        % Nx2 matrix
u_alpha = u_data(:,1);             % first column
du_ign  = u_data(:,2);             % second column

u_ref  = urSig.Values.Data;        % Nx2 matrix
du_ref  = duSig.Values.Data;        % Nx2 matrix

err = omega_r - omega;
RMSE = sqrt(mean(err.^2));

%% Plots
figure('Name','Closed-loop response','Position',[100 100 600 700]);

subplot(3,1,1);
plot(t_ref, omega_r, 'LineWidth',1); hold on;
plot(t, omega, 'LineWidth',1.5);
grid on;
ylabel('\omega_{norm}');
legend('ref','actual');
title('Normalized engine speed, RMSE: ', RMSE);

subplot(3,1,2);
plot(t_ur, u_ref, 'LineWidth',1); hold on;
plot(t_u, u_alpha, 'LineWidth',1.5);
grid on;
ylabel('u_\alpha (norm)');
legend('ref','actual');

subplot(3,1,3);
plot(t_u, du_ign, 'LineWidth',1);hold on;
%plot(t_ign, ign_in, 'LineWidth',1.5);
grid on;
ylabel('\Delta u_{ign} (norm)');
xlabel('Time [s]');
legend('contr','input');

%% 1. Build continuous-time plant and controller

% Plant from linearization (10-state, 2-input, 1-output)
P = ss(A, B, C, D);          % sizes: A(10x10), B(10x2), C(1x10), D(1x2)

% Continuous-time controller (12-state, 1-input, 2-output)
Ccont = ss(ISCSAc, ISCSBc, ISCSCc, ISCSDc);   % from build_controller.m

%% 2. Open-loop transfer function L(s) = P(s) * C(s)
L = P * Ccont;               % 1x1 SISO from error -> omega_norm

size(L)                      % should be 1x1

%% 3. Bode + margins to get crossover frequency

figure;
margin(L);                   % Bode + gain & phase margins
grid on;

[GM, PM, wcg, wcp] = margin(L);

fprintf('Gain crossover frequency (wcg)  = %.3f rad/s\n', wcg);
fprintf('Phase crossover frequency (wcp) = %.3f rad/s\n', wcp);
fprintf('Gain margin  = %.2f dB\n', 20*log10(GM));
fprintf('Phase margin = %.2f deg\n', PM);
