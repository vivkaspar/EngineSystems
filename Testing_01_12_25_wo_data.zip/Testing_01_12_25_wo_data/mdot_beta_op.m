function mdot_beta = mdot_beta_op(p_m, T_m, p_e, omega_e, gamma0, gamma1)
%#codegen
% Params (make these mask params or Simulink.Parameter)
R      = 287;       % J/(kg*K)
kap    = 1.35;
sigma0 = 14.67;     % stoich AFR
Vd     = 2.48e-3;   % m^3
Vc     = 2.48e-4;   % m^3
lambda = 1.0;       % AFR ratio (expose later)

% Numeric guards (physical floors)
pm = max(p_m, 1.0);
Tm = max(T_m, 100.0);
pe = max(p_e, 1.0);
om = max(omega_e, 0.0);

% Manifold density
rho_m = pm/(R*Tm);

% Volumetric efficiency
lambda_lp = max((Vc + Vd)/Vd - (Vc/Vd)*(pe/pm)^(1/kap), 0.0);
lambda_lw = min(max(gamma0 + gamma1*om, 0.0), 1.2);
lambda_l  = lambda_lp * lambda_lw;

% Fresh mixture entering the cylinders (one intake per 2 revs)
mdot_e = 0.5 * rho_m * lambda_l * Vd * (om/(2*pi));  % = rho*lambda*Vd*om/(4*pi)

% Air leaving manifold (lambda may vary later)
mdot_beta = mdot_e / (1 + 1/(max(lambda,1e-6)*sigma0));

% Nonnegative
mdot_beta = max(mdot_beta, eps);
