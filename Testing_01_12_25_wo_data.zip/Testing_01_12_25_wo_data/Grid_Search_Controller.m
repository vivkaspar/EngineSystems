%% auto_tune_iscs.m  (updated)
clc; clear; close all;

%% ------------------------------------------------------------------------
% 1) Fixed data, plant & linearization
% -------------------------------------------------------------------------
run Parameters.m

opts.u_alpha_pct_tol = 2.5;
opts.du_ign_deg_tol  = 10.0;
opts.domega_dt_tol   = 20.0;
opts.min_window_s    = 0.5;
opts.smooth_win      = 21;
opts.showPlot        = false;

op = m3_pick_idle_op('ISCSData/studentId_0009', 2.0, opts);

omega_nom   = op.omega_e_rads;
u_alpha_nom = op.u_alpha_pct;
du_ign_nom  = max(1, op.du_ign_deg);
m_beta_nom  = op.mdot_beta;
u_IPS_nom   = m_beta_nom;
delta_u_zeta_nom = -25;

tau_IPS_nom = 2*pi/omega_nom;
tau_seg_nom = 4*pi/(5*omega_nom);
tau_ign_nom = tau_seg_nom/2;

order = 4;
[A_IPS,B_IPS,C_IPS,D_IPS,x0_IPS] = makePadeBlock(tau_IPS_nom, u_IPS_nom, order);
[A_ign,B_ign,C_ign,D_ign,x0_ign] = makePadeBlock(tau_ign_nom, delta_u_zeta_nom, order);

simopt = simset('Solver','ode1','FixedStep',1e-3,'SrcWorkspace','current');
sim('Pade_Norm_Engine_model_m3', 5, simopt);

[A,B,C,D] = linmod('Pade_Norm_Engine_model');
As = A; Bs = B; Cs = C; Ds = D;
P  = ss(As,Bs,Cs,Ds);

%% ------------------------------------------------------------------------
% 2) Requirements and search grids
% -------------------------------------------------------------------------
RMSE_max    = 0.10;    % performance requirement
wgc_max     = 4.0;     % *** gain crossover frequency limit [rad/s] ***
PM_min_deg  = 45;      % phase margin
GM_min_dB   = 6;       % gain margin

% *** throttle smoothness requirement ***
du_step_max = 1.50;    % max |u_alpha(k)-u_alpha(k-1)| (tune as you like)

% Search grids
KI_grid      = [0.5 1 2 3];
q_obs_grid   = [0.01 0.1 1];
r1_grid      = [0.05 0.1 0.5 1];
r2_grid      = [0.5 1 2 5 10];
Qspeed_grid  = [5 10 20];
Qint_grid    = [10 50 100];

Ts = 1e-3;

found       = false;
bestRMSE    = inf;
bestRough   = inf;   % to break ties by smoothness
bestInfo    = struct();

%% ------------------------------------------------------------------------
% 3) Grid search
% -------------------------------------------------------------------------
for KI = KI_grid
    for q_obs = q_obs_grid
        for qx1 = Qspeed_grid
            for qv = Qint_grid
                for r1 = r1_grid
                    for r2 = r2_grid

                        fprintf('\nTrying KI=%.3g, q=%.3g, Qx1=%.3g, Qv=%.3g, r1=%.3g, r2=%.3g ...\n',...
                                KI,q_obs,qx1,qv,r1,r2);
                        try
                            % ---------- LQGI design ----------
                            Ae = 0; Be = [1 0]; Ce = [KI; 0]; De = eye(2);

                            A_ext = [As,              Bs*Ce;
                                     zeros(1,size(As,1)) Ae];
                            B_ext = [Bs*De;
                                     Be];
                            C_ext = [Cs, Ds*Ce];
                            D_ext = Ds*De;

                            nx_ext = size(A_ext,1);

                            q_diag         = ones(1,nx_ext);
                            q_diag(1)      = qx1;   % speed
                            q_diag(end)    = qv;    % integrator
                            Q_ext          = diag(q_diag);
                            R              = diag([r1 r2]);

                            [K_ext,~,eig_cl_ext] = lqr(A_ext,B_ext,Q_ext,R);
                            L_ext = lqr(A_ext',C_ext',B_ext*B_ext',q_obs)';

                            A = A_ext; B = B_ext; C = C_ext;
                            K = K_ext; L = L_ext;
                            n  = size(A,1); nu = size(B,2);

                            Ae_c = 0; Be_c = [1 0]; Ce_c = [KI; 0]; De_c = eye(2);

                            ISCSAc = [Ae_c      -Be_c*K;
                                      zeros(n,1) A - B*K - L*C];
                            ISCSBc = [0;
                                     -L];
                            ISCSCc = [Ce_c  -De_c*K];
                            ISCSDc = zeros(2,1);

                            % ---------- margins (open loop) ----------
                            Ccont_OL = ss(ISCSAc,ISCSBc,ISCSCc,ISCSDc);
                            L_ol     = P * Ccont_OL;
                            [GM, PM, wcg, wcp] = margin(L_ol);
                            GMdB = 20*log10(GM);

                            if any(isnan([PM,GMdB,wcg,wcp]))
                                fprintf('  -> margins NaN, skipping.\n');
                                continue;
                            end

                            % Requirements on robustness & bandwidth
                            if wcg > wgc_max || PM < PM_min_deg || GMdB < GM_min_dB
                                fprintf('  -> margins fail: wgc=%.2f, wcp=%.2f, PM=%.1f, GM=%.1f dB\n',...
                                        wcg,wcp,PM,GMdB);
                                continue;
                            end

                            % ---------- discrete controller for Simulink ----------
                            Ccont = ss(ISCSAc,ISCSBc,ISCSCc,ISCSDc);
                            Cdisc = c2d(Ccont, Ts, 'tustin');
                            [Ad_c,Bd_c,Cd_c,Dd_c] = ssdata(Cdisc);
                            save('ControllerX.mat','Ad_c','Bd_c','Cd_c','Dd_c');

                            % ---------- nonlinear sim ----------
                            model = 'Pade_Norm_Engine_model_Controller';
                            Tsim  = 90;

                            simIn = Simulink.SimulationInput(model);
                            simIn = setModelParameter(simIn,'StopTime',num2str(Tsim));
                            simIn = setModelParameter(simIn,'ReturnWorkspaceOutputs','on');

                            simOut = sim(simIn);

                            logs  = simOut.logsout;
                            uSig  = logs{1};
                            duSig = logs{2};
                            ySig  = logs{3};
                            rSig  = logs{4};
                            urSig = logs{5};

                            t       = ySig.Values.Time;
                            omega   = ySig.Values.Data;
                            omega_r = rSig.Values.Data;

                            t_u     = uSig.Values.Time;
                            u_data  = uSig.Values.Data;
                            u_alpha = u_data(:,1);
                            du_ign  = u_data(:,2);

                            u_ref   = urSig.Values.Data;
                            du_ref  = duSig.Values.Data;

                            err  = omega_r - omega;
                            RMSE = sqrt(mean(err.^2));

                            % ---------- throttle smoothness metric ----------
                            du_step = diff(u_alpha);           % sample-to-sample jumps
                            rough   = max(abs(du_step));       % peak jump size

                            fprintf(['  -> RMSE=%.4f, rough=%.3g, wgc=%.2f, ' ...
                                     'wcp=%.2f, PM=%.1f, GM=%.1f dB\n'], ...
                                    RMSE, rough, wcg, wcp, PM, GMdB);

                            % Check requirements
                            if RMSE > RMSE_max || rough > du_step_max
                                % update "best so far" even if not meeting constraints
                                if (RMSE < bestRMSE) || ...
                                   (abs(RMSE-bestRMSE) < 1e-4 && rough < bestRough)
                                    bestRMSE  = RMSE;
                                    bestRough = rough;
                                end
                                continue;
                            end

                            % Feasible solution found
                            found    = true;
                            bestRMSE = RMSE;
                            bestRough = rough;
                            bestInfo = struct('KI',KI,'q',q_obs,...
                                              'Qx1',qx1,'Qv',qv,...
                                              'r1',r1,'r2',r2,...
                                              'wgc',wcg,'wcp',wcp,...
                                              'PM',PM,'GMdB',GMdB,...
                                              'eig_cl',eig_cl_ext,...
                                              'Ad_c',Ad_c,'Bd_c',Bd_c,...
                                              'Cd_c',Cd_c,'Dd_c',Dd_c,...
                                              't',t,'omega',omega,...
                                              'omega_r',omega_r,...
                                              't_u',t_u,...
                                              'u_alpha',u_alpha,...
                                              'du_ign',du_ign,...
                                              'u_ref',u_ref,...
                                              'du_ref',du_ref);
                            fprintf('*** FEASIBLE CONTROLLER FOUND ***\n');
                            break;

                        catch ME
                            fprintf('  -> Error: %s\n', ME.message);
                            continue;
                        end

                    end
                    if found, break; end
                end
                if found, break; end
            end
            if found, break; end
        end
        if found, break; end
    end
    if found, break; end
end

%% ------------------------------------------------------------------------
% 4) Report and final plot
% -------------------------------------------------------------------------
if found
    fprintf('\n========= SUCCESS =========\n');
    disp(bestInfo);

    figure('Name','Closed-loop response (best)','Position',[100 100 600 700]);

    subplot(3,1,1);
    plot(bestInfo.t, bestInfo.omega_r, 'LineWidth',1); hold on;
    plot(bestInfo.t, bestInfo.omega,   'LineWidth',1.5);
    grid on; ylabel('\omega_{norm}');
    legend('ref','actual');
    title(sprintf('Normalized speed, RMSE = %.4f', bestRMSE));

    subplot(3,1,2);
    plot(bestInfo.t_u, bestInfo.u_ref,    'LineWidth',1); hold on;
    plot(bestInfo.t_u, bestInfo.u_alpha,  'LineWidth',1.5);
    grid on; ylabel('u_\alpha (norm)');
    legend('ref','actual');
    title(sprintf('Throttle, max jump = %.3g', bestRough));

    subplot(3,1,3);
    plot(bestInfo.t_u, bestInfo.du_ref, 'LineWidth',1); hold on;
    plot(bestInfo.t_u, bestInfo.du_ign, 'LineWidth',1.5);
    grid on; ylabel('\Delta u_{ign} (norm)');
    xlabel('Time [s]');

else
    fprintf('\nNO PARAMETER COMBINATION MET ALL HARD REQUIREMENTS.\n');
    fprintf('Best RMSE encountered   = %.4f\n', bestRMSE);
    fprintf('Best throttle roughness = %.4g (du_step_max=%.4g)\n', bestRough, du_step_max);
end
