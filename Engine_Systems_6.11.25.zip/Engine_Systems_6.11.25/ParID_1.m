
%Parameter Identification of Engine Air Mass Flow
data1 = load('ISCSData/quasistatic_0001.mat');
Data = data1.meas;

%p_e1 = data1.meas.p_e;
%p_a1 = data1.meas.p_a;
%theta_a1 = data1.meas.T_a;
%theta_m1 = data1.meas.T_m;
%P_l1 = data1.meas.P_l;
%u_alpha1 = data1.meas.u_alpha;
%du_zeta1 = data1.meas.du_ign;
%u_l1 = data1.meas.u_l;
%mdot_alpha1 = data1.meas.m_dot_alpha;

%omega_e1 = data1.meas.omega_e;
%p_m1 = data1.meas.p_m;


y = Data.m_dot_alpha.signals.values.*sqrt(2*par.R*Data.T_a.signals.values)./Data.p_a.signals.values;

M = [ones(length(Data.u_alpha.signals.values), 1), Data.u_alpha.signals.values];


x = lsqr(M,y,1e-15,500);


A_alpha1 = x(1) +x(2).* Data.u_alpha.signals.values;
V = sum((y-A_alpha1).^2);
disp(x)
disp(V)


par.alpha_0_opt = x(1);
par.alpha_1_opt = x(2);



%% --- Plot der Messpunkte und der linearisierten Linie (A_alpha1 vs. u_alpha) ---
figure('Name','Throttle Flow Characteristic','Color','w');
hold on; grid on; box on;

% --- 1) Messdatenpunkte ---
plot(Data.u_alpha.signals.values, y, 'kx', 'LineWidth', 1.2, ...
    'DisplayName', 'Messpunkte');

% --- 2) Berechnete linearisierte Linie ---
u_alpha_range = linspace(min(Data.u_alpha.signals.values), max(Data.u_alpha.signals.values), 200);
alpha_fit = x(1) + x(2) .* u_alpha_range;

plot(u_alpha_range, alpha_fit, 'k-', 'LineWidth', 1.5, ...
    'DisplayName', sprintf('Fit: A_{\\alpha1}(u_{\\alpha}) = %.3f + %.3e·u_{\\alpha}', x(1), x(2)));

% --- 3) Achsen & Beschriftungen ---
xlabel('u_{\alpha} [-]', 'Interpreter','tex');
ylabel('A_{\alpha1}(u_{\alpha}) [-]', 'Interpreter','tex');
title('Identifikation der Drosselklappenkennlinie A_{\alpha1}(u_{\alpha})', 'FontWeight','normal');
legend('Location','best');

% --- 4) Layout an Dokumentationsstil anpassen ---
set(gca, 'FontName','Times New Roman', 'FontSize',12, 'LineWidth',1);
grid on; box on;

hold off;