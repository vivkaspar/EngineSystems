

data1 = load('ISCSData/quasistatic_0001.mat');

Data = data1.meas;



R = 287;

lambda_lp = (par.Vc+par.Vd)/par.Vd - par.Vc/par.Vd* (Data.p_e.signals.values./Data.p_m.signals.values).^(1/par.kappa);
y = 4*pi*par.R/par.Vd*Data.m_dot_alpha.signals.values.*Data.T_m.signals.values./(Data.p_m.signals.values.*Data.omega_e.signals.values.*lambda_lp).*(1+1./(Data.lambda.signals.values*par.sigma_0));
M = [ones(length(Data.omega_e.signals.values), 1), Data.omega_e.signals.values];


x = lsqr(M,y,1e-15,500);

lambda_lw1 = x(1) +x(2).* Data.omega_e.signals.values;
V = sum((y-lambda_lw1).^2);
disp(x)
disp(V)

par.gamma_0_opt = x(1);
par.gamma_1_opt= x(2);

%% --- Plot der Messpunkte und der linearisierten Linie ---
figure;
hold on; grid on; box on;

% Plot der Messdatenpunkte
plot(Data.omega_e.signals.values, y, 'o', 'MarkerFaceColor', [0 0.447 0.741], ...
    'MarkerEdgeColor', 'k', 'DisplayName', 'Messpunkte');

% Berechnete linearisierte Linie
omega_range = linspace(min(Data.omega_e.signals.values), max(Data.omega_e.signals.values), 200);
lambda_fit = x(1) + x(2) .* omega_range;

% Plot der linearen Regression
plot(omega_range, lambda_fit, 'LineWidth', 2, 'Color', [0.85 0.325 0.098], ...
    'DisplayName', sprintf('Linearisiert: \\lambda = %.3f + %.3f \\cdot \\omega_e', x(1), x(2)));

% Achsenbeschriftungen und Titel
xlabel('\omega_e [rad/s]');
ylabel('\lambda_{lw1} [-]');
title('Linearisierte Beziehung zwischen \lambda_{lw1} und \omega_e');

legend('Location', 'best');
hold off;