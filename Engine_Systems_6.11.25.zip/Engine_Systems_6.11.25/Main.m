clc;
clearvars;
close all;
run Parameters
run ParID_1
run ParID_2
run ParID_3
run ParID_4
run Parameters
disp(par.alpha_0)
disp(par.alpha_1)
disp(par.gamma_0)
disp(par.gamma_1)
disp(par.Vm)
disp(par.eta_0)
disp(par.eta_1)
disp(par.beta_0)
disp(par.theta_e)


