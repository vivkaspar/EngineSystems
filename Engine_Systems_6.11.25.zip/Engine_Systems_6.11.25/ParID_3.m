%clc;
%clearvars;
%close all;

%run Parameters

par0 = par.Vm_init;

opt_options = optimset('TolFun',1e-4,'TolX',1e-4,'MaxIter',200,'MaxFunEvals',2000,'Display','iter');

Data = data_stud_1.meas;
errorfnc_fminsearch = @(par0) ModelerrorParID_3(par0, Data, par, 'Parameter Identification');
tic
optpar = fminsearch(errorfnc_fminsearch, par0, opt_options);
opt_dur = toc;

par.Vm_opt         = optpar;

close all 

fprintf('V_m = %1.5f\n', par.Vm_opt) % \n means new line, 1.5f means float variable and 5 decimals displayed

% load validation data

Data = data_stud_2.meas;
% evaluate model

ModelerrorParID_3(par.Vm_opt,Data,par,'Evaluation on Validation Data');
% you can simply use the plot commands which you already wrote in the 
% Modelerror file. As inputs, the identified optimal parameters are used.
