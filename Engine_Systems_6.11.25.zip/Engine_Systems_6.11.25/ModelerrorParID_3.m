function e = ModelerrorParId_3(params, Data, par, FigureTitle)
par.Vm     = params;
%run Parameters
par.p_m_init     = Data.p_m.signals.values(1);
par.p_zero = Data.p_m.signals.values(1);
par.omega_zero = Data.omega_e.signals.values(1);
par.end_time = Data.omega_e.time(end);
par.du_ign_zero = Data.du_ign.signals.values(1);

[time, x, y1] = sim('NonlinearModel_ParID_3', [Data.u_alpha.time(1), Data.u_alpha.time(end)], par.simopt);


y_on_meas_t = interp1(time(:), y1(:), Data.p_m.time(:), 'linear', 'extrap');

e = sum( (Data.p_m.signals.values(:) - y_on_meas_t(:)).^2 );

if par.enablePlot
    col = lines(2);
    figure(101); clf; set(gcf,'Name',FigureTitle);
    subplot(3,1,1); box on; grid on;
    plot(Data.u_alpha.time, Data.u_alpha.signals.values, 'Color', col(1,:));
    ylabel('u_\alpha [% or frac]'); xlim([Data.u_alpha.time(1) Data.u_alpha.time(end)]); title(FigureTitle);

    subplot(3,1,2); box on; grid on;
    plot(Data.u_l.time, Data.u_l.signals.values, 'k', 'LineWidth',1.5);
    ylabel('u_l  [on/off]');
    ylim([-0.1 1.1]);
    xlim([Data.u_alpha.time(1) Data.u_alpha.time(end)]);
    
    subplot(3,1,3); box on; grid on;
    plot(Data.p_m.time, Data.p_m.signals.values, 'Color', col(1,:)); hold on;
    plot(Data.p_m.time, y_on_meas_t, 'Color', col(2,:), 'LineWidth', 1.4); hold off;
    xlabel('t [s]'); ylabel('p\_m [Pa]'); legend('meas','sim');
    xlim([Data.u_alpha.time(1) Data.u_alpha.time(end)]);
    drawnow;
end
end
