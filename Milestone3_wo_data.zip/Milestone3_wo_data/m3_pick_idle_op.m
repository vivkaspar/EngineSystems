function op = m3_pick_idle_op(dataFile, targetThrottlePct, opts)
% MILESTONE 3 — STEP 1:
% Pick a single steady idle operating point (equilibrium) from data.
%
% Usage:
%   op = m3_pick_idle_op('dynamic_0003.mat', 3.0);
%
% Inputs:
%   dataFile            MAT file containing struct 'meas' with fields:
%                       u_alpha, u_l, du_ign, omega_e, p_m, (optionally T_m, p_a, p_e)
%   targetThrottlePct   target throttle in percent (e.g., 3.0)
%   opts                (optional) struct with thresholds below
%
% Output 'op' fields (equilibrium values at t*):
%   .tstar
%   .u_alpha_pct
%   .u_alpha_frac
%   .u_l
%   .du_ign_deg
%   .omega_e_rads
%   .p_m_Pa
%   .T_m_K           (if available; else NaN)
%   .p_a_Pa          (if available; else NaN)
%   .p_e_Pa          (if available; else NaN)
%   .idx             (sample index at t*)
%
% Side effects:
%   Assigns useful IC variables to base workspace for your Simulink model:
%     par.p_m_init, par.omega_e_init
%     op (the struct itself)
%run Parameters.m
% ---------- defaults ----------
if nargin < 2 || isempty(targetThrottlePct), targetThrottlePct = 3.0; end
if nargin < 3,  opts = struct; end
d = @default;  % tiny helper
thr.u_alpha_pct_tol = d(opts,'u_alpha_pct_tol', 1.0);     % ±0.3 % around target
thr.du_ign_deg_tol  = d(opts,'du_ign_deg_tol', 1.0);      % |du_ign| ≤ 0.5 deg
thr.domega_dt_tol   = d(opts,'domega_dt_tol', 0.8);       % |dω/dt| ≤ 0.8 rad/s^2
thr.min_window_s    = d(opts,'min_window_s',  1.0);       % need ≥ this many contiguous seconds
thr.smooth_win      = d(opts,'smooth_win',    11);        % moving window for slope
showPlot            = d(opts,'plot',          true);

% ---------- load data ----------
S    = load(dataFile);
Data = S.meas;

% shorthand handles (all assumed column vectors)
t       = Data.u_alpha.time(:);
u_pct   = Data.u_alpha.signals.values(:);     % throttle in percent
u_l     = Data.u_l.signals.values(:);         % load on/off (0/1)
du_deg  = Data.du_ign.signals.values(:);      % degrees
omega   = Data.omega_e.signals.values(:);     % rad/s
p_m     = Data.p_m.signals.values(:);         % Pa

% optional signals
T_m = get_opt(Data,'T_m');     % K or []
T_a = get_opt(Data,'T_a');     % K or []
P_l = get_opt(Data,'P_l');     % K or []
p_a = get_opt(Data,'p_a');     % Pa or []
p_e = get_opt(Data,'p_e');     % Pa or []

% ---------- compute steady-ness (dω/dt) ----------
dt      = [diff(t); median(diff(t))];
domega  = [diff(omega); 0] ./ dt;
% smooth a bit to avoid false negatives
if thr.smooth_win > 1
    w = thr.smooth_win;
    domega = movmean(domega, w, 'Endpoints','shrink');
end

% ---------- build masks ----------
M_throttle = abs(u_pct - targetThrottlePct) <= thr.u_alpha_pct_tol;
M_load     = (u_l == 0);
M_ign      = abs(du_deg) <= thr.du_ign_deg_tol;
M_slope    = abs(domega) <= thr.domega_dt_tol;

M_all = M_throttle & M_load & M_ign & M_slope;

% require a contiguous window of length ≥ min_window_s
minN = max(1, round(thr.min_window_s / median(diff(t))));
M_all = enforce_min_run(M_all, minN);

if ~any(M_all)
    error(['No steady idle sample found near ' num2str(targetThrottlePct) '% ' ...
           'with current thresholds. Loosen opts.* or inspect your data.']);
end

% ---------- pick the best single instant t* ----------
% preference: smallest |u - target| and smallest |dω/dt|
score = 10*abs(u_pct - targetThrottlePct) + abs(domega);  % weights
score(~M_all) = inf;
[~, idx] = min(score);
tstar = t(idx);

gamma0 = 0.6;
gamma1 = 0.002;

% ---------- pack results ----------
op.tstar        = tstar;
op.idx          = idx;
op.u_alpha_pct  = u_pct(idx);
op.u_alpha_frac = u_pct(idx) * 0.01;
op.u_l          = u_l(idx);
op.du_ign_deg   = du_deg(idx);
op.omega_e_rads = omega(idx);
op.p_m_Pa       = p_m(idx);
op.T_m_K        = pick_or_nan(T_m, idx);
op.T_a_K        = pick_or_nan(T_a, idx);
op.p_a_Pa       = pick_or_nan(p_a, idx);
op.p_e_Pa       = pick_or_nan(p_e, idx);
op.P_l          = pick_or_nan(P_l, idx);
op.mdot_beta    = mdot_beta_op(p_m(idx), op.T_m_K, op.p_e_Pa, op.omega_e_rads, gamma0, gamma1);

% ---------- push useful ICs to base (for your model blocks) ----------
try
    par = evalin('base','par');  % fetch existing 'par' if present
catch
    par = struct;
end
par.p_m_init     = op.p_m_Pa;
par.omega_e_init = op.omega_e_rads;

assignin('base','par', par);
assignin('base','op',  op);

% ---------- tiny report ----------
fprintf('Milestone 3 — picked idle operating point:\n');
fprintf('  t* = %.3f s | u_alpha = %.3f %% (%.4f frac) | u_l = %d | du_ign = %.3f deg\n', ...
    op.tstar, op.u_alpha_pct, op.u_alpha_frac, op.u_l, op.du_ign_deg);
fprintf('  omega_e = %.3f rad/s | p_m = %.0f Pa', op.omega_e_rads, op.p_m_Pa);
if ~isnan(op.T_m_K), fprintf(' | T_m = %.1f K', op.T_m_K); end
if ~isnan(op.p_e_Pa), fprintf(' | p_e = %.0f Pa', op.p_e_Pa); end
fprintf('\n');

% ---------- quick visual confirmation ----------
if showPlot
    col = lines(3);
    figure(301); clf; set(gcf,'Name','Idle operating point selection');
    subplot(4,1,1); box on; grid on;
    plot(t, u_pct, 'Color', col(1,:)); hold on;
    yline(targetThrottlePct,'--','Target'); scatter(tstar, op.u_alpha_pct, 36, 'k','filled');
    ylabel('u_\alpha [%]'); xlim([t(1) t(end)]); title('Selection masks & t*');
    legend('u_\alpha','target','t^*','Location','best'); hold off;

    subplot(4,1,2); box on; grid on;
    stairs(t, u_l, 'k'); hold on; scatter(tstar, op.u_l, 36,'k','filled'); hold off;
    ylabel('u_l [0/1]'); ylim([-0.1 1.1]); xlim([t(1) t(end)]);

    subplot(4,1,3); box on; grid on;
    plot(t, du_deg, 'Color', col(2,:)); hold on;
    yline([thr.du_ign_deg_tol, -thr.du_ign_deg_tol],'k:'); scatter(tstar, op.du_ign_deg, 36,'k','filled');
    ylabel('\Delta u_{ign} [deg]'); xlim([t(1) t(end)]);

    subplot(4,1,4); box on; grid on;
    plot(t, omega, 'Color', col(3,:)); hold on;
    plot(t, domega, 'm:'); yline([thr.domega_dt_tol, -thr.domega_dt_tol],'k:');
    scatter(tstar, op.omega_e_rads, 36,'k','filled');
    xlabel('t [s]'); ylabel('\omega_e [rad/s]  (magenta: d\omega/dt)');
    xlim([t(1) t(end)]);
end

% ------------ helpers ------------
function val = default(s, field, dv)
    if isfield(s,field) && ~isempty(s.(field)), val = s.(field); else, val = dv; end
end

function A = get_opt(D, name)
    if isfield(D, name) && isfield(D.(name),'signals')
        A = D.(name).signals.values(:);
    else
        A = [];
    end
end

function v = pick_or_nan(arr, i)
    if isempty(arr), v = NaN; else, v = arr(i); end
end

function M2 = enforce_min_run(M, Nmin)
% keep only runs of true with length >= Nmin
    M2 = false(size(M));
    if ~any(M), return; end
    dM = diff([false; M; false]);
    runStarts = find(dM==1);
    runEnds   = find(dM==-1)-1;
    lens = runEnds - runStarts + 1;
    for k=1:numel(lens)
        if lens(k) >= Nmin
            M2(runStarts(k):runEnds(k)) = true;
        end
    end
end
end
