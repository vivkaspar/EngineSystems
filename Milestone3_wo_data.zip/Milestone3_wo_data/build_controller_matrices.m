%% build_controller.m
% Build continuous-time ISCS controller matrices according to Fig. 2.16

% Assumes in workspace:
%   As,Bs,Cs,Ds        % original linearized plant
%   A_ext,B_ext,C_ext,D_ext   % extended plant (step 1)
%   K_ext,L_ext        % LQR and observer on extended plant
%   KI                 % integral gain used in Ae,Be,Ce

%% 1) Alias extended plant and gains

A = A_ext;
B = B_ext;
C = C_ext;
% D = D_ext;   % not actually needed here

K = K_ext;    % 2 x n_ext
L = L_ext;    % n_ext x 1

n  = size(A,1);   % n_ext = 11 in your case
nu = size(B,2);   % 2 inputs (throttle, ignition)

%% 2) Extension matrices (eq. 2.6)

Ae = 0;
Be = [1 0];           % 1 x 2
Ce = [KI; 0];         % 2 x 1
De = eye(2);          % 2 x 2

%% 3) ISCS A matrix (12x12)

ISCSAc = [ Ae              -Be*K ;         % 1 x 1   | 1 x n
           zeros(n,1)  A - B*K - L*C ];    % n x 1   | n x n

%% 4) ISCS B matrix (12x1)
% LQG controller has Dc = 0 by definition => Be*Dc = 0

Dc = zeros(nu,1);      % 2 x 1, but zero ⇒ Be*Dc = 0_(1x1)

ISCSBc = [ 0 ;         % Be*Dc = 0 (1x1)
          -L ];        % n x 1

%% 5) ISCS C matrix (2x12)

ISCSCc = [ Ce   -De*K ];   % 2 x (1+n)

%% 6) ISCS D matrix (2x1)

ISCSDc = De*Dc;            % 2 x 1, all zeros

%% 7) Quick size check

sizeA = size(ISCSAc);
sizeB = size(ISCSBc);
sizeC = size(ISCSCc);
sizeD = size(ISCSDc);

Ts = 1e-3;   % controller sampling time [s]

Ccont = ss(ISCSAc, ISCSBc, ISCSCc, ISCSDc);
Cdisc = c2d(Ccont, Ts, 'tustin');

[Ad_c, Bd_c, Cd_c, Dd_c] = ssdata(Cdisc);

save('ControllerX.mat', ...
     'Ad_c','Bd_c','Cd_c','Dd_c');


disp(Ad_c); disp(Bd_c); disp(Cd_c); disp(Dd_c);

