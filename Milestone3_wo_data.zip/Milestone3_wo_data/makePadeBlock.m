function [A,B,C,D,x0] = makePadeBlock(Td, u0, order)
%MAKEPADEBLOCK  Build an Nth-order Pade approx. for a pure delay
%   Td    : delay time [s] (at the chosen operating point)
%   u0    : nominal (constant) input at operating point
%   order : Pade order (use 4 for the exercise)
%
%   Returns state-space matrices A,B,C,D and the steady-state
%   initial condition x0 so that y(t) = u0 at t=0.

    if nargin < 3
        order = 4;
    end
   
    Td = 0.0354;
    % TF of e^(-Td s) approximated by Nth-order Padé
    [num,den] = pade(Td, order);
    sys       = ss(tf(num,den));

    u0    = 2.78e-5;

    A = sys.A;
    B = sys.B;
    C = sys.C;
    D = sys.D;

    % Steady-state for constant input u0: 0 = A x0 + B u0
    % (Padé has DC gain 1, so y0 = C x0 + D u0 = u0 automatically)
    x0 = -(A\B) * u0;
    if true
        % True time delay as transfer function with InputDelay
        G_delay = tf(1,1,'InputDelay',Td);
        G_pade  = tf(num,den);

        % Time vector
        if Td > 0
            tEnd = 5*Td;
        else
            tEnd = 1;  % fallback if Td=0
        end
        t = linspace(0, tEnd, 1000);

        % Step of magnitude u0
        [y_delay,t1] = step(u0*G_delay, t);
        [y_pade,t2]  = step(u0*G_pade,  t);

        figure;
        plot(t1, y_delay, 'LineWidth', 1.5); hold on;
        plot(t2, y_pade, '--', 'LineWidth', 1.5);
        grid on;
        xlabel('Time [s]');
        ylabel('Output');
        title(sprintf('Pure delay vs %d^{th}-order Padé (T_d = %.3g s, u_0 = %.3g)', ...
              order, Td, u0));
        legend('True delay','Padé approximation','Location','Best');
    end
end