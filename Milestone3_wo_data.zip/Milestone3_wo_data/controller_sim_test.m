model = 'Pade_Norm_Engine_model_Controller';  % change if needed
Tsim  = 90;                                    % [s]

%% Set up SimulationInput so we always get a SimulationOutput object
simIn = Simulink.SimulationInput(model);
simIn = setModelParameter(simIn,'StopTime',num2str(Tsim));
simIn = setModelParameter(simIn,'ReturnWorkspaceOutputs','on');

%% Run simulation
simOut = sim(simIn);

%% Extract signals from logsout by index
logs = simOut.logsout;

uSig   = logs{1};   % [u_alpha, du_ign]
urSig  = logs{5};
duSig  = logs{2};
rSig   = logs{4};   % omega_norm_ref
ySig   = logs{3};   % omega_e_norm

t       = ySig.Values.Time;
t_u     = uSig.Values.Time;
t_ur    = urSig.Values.Time;
t_du    = duSig.Values.Time;
t_ref   = rSig.Values.Time;

omega   = ySig.Values.Data;        % scalar
omega_r = rSig.Values.Data;        % scalar

u_data  = uSig.Values.Data;        % Nx2 matrix
u_alpha = u_data(:,1);             % first column
du_ign  = u_data(:,2);             % second column

u_ref  = urSig.Values.Data;        % Nx2 matrix
du_ref  = duSig.Values.Data;        % Nx2 matrix

%% Plots
figure('Name','Closed-loop response','Position',[100 100 600 700]);

subplot(3,1,1);
plot(t_ref, omega_r, 'LineWidth',1); hold on;
plot(t, omega, 'LineWidth',1.5);
grid on;
ylabel('\omega_{norm}');
legend('ref','actual');
title('Normalized engine speed');

subplot(3,1,2);
plot(t_ur, u_ref, 'LineWidth',1); hold on;
plot(t_u, u_alpha, 'LineWidth',1.5);
grid on;
ylabel('u_\alpha (norm)');
legend('ref','actual');

subplot(3,1,3);
plot(t_u, du_ign, 'LineWidth',1);
plot(t_du, du_ref, 'LineWidth',1.5);
grid on;
ylabel('\Delta u_{ign} (norm)');
xlabel('Time [s]');